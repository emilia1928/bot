# -*- coding: utf-8 -*-

import LINETCR
from LINETCR.lib.curve.ttypes import *
from datetime import datetime
import requests,tempfile,gtts
from gtts import gTTS
from bs4 import BeautifulSoup
import string,os,shutil,urllib,urllib2,urllib3,subprocess
import time,random,sys,json,codecs,threading,glob,re,ast,wikipedia,string,unicodedata,goslate,tempfile,ctypes,codecs,tweepy
from time import sleep
from urllib import urlopen

#🔸Me
cl = LINETCR.LINE()
#cl.login(qr=True)
cl.login(token="En9W7rq1WUn0KoIKLH2d.kPCC2cheTsBk4ifKqk7WRq.UR1OKKXtpfxplHm0KXZDs5AhryLSo7GSAfBSRbh6zG4=")
cl.loginResult()
#🔸Ram
ki = LINETCR.LINE()
ki.login(token="EnG8m1DIvjVG3BJCfXYb.eYEa7xHBtex0js+NkxbMMW.9jP0MQl0s9W18o2WDXeme+4y+SsquCWVLoRPXQyIcXY=")
ki.loginResult()
#🔸Rem
kk = LINETCR.LINE()
kk.login(token="Enw35PLt2uL54mXKzSRb.qcURbB0UMDI4dQBAOcnMUW.dql25+xMCw+yzPvyIJae9cSbTHOGE5T1UtT3N6hm5WU=")
#Remkk.login(token="Eml40CYx7jcwTSZGLFUb.qcURbB0UMDI4dQBAOcnMUW.ddgUovzYYHPN6oqGrdKPOKYkZCLEfrz99MtVfBJuUQ4=")
kk.loginResult()
#🔸Emilia
kc = LINETCR.LINE()
kc.login(token="EnPKvyamkwraFP62Dqk7.oQ3qV4oMI0TEZAtwnLvkXW.i3Gua6WuLMxybB+KRfd78oaT7f8QvWotAQytMNIY6YE=")
kc.loginResult()
#🔸Raphiel
ks = LINETCR.LINE()
ks.login(token="Enx7PynRGSLG8LtASpPc.PbGVtJjdxHS3kIJJN01VBa.5hWFaB7IvIyTCMOi9OzeXvQUapc/iE1hdsu1S5FihaY=")
ks.loginResult()
#🔸Gabriel
ka = LINETCR.LINE()
ka.login(token="EnJpaoPLKWUK6kbfgME7.57LdoM1EOU0JLa4AUA56zW.ejb7rFaJb+5ZjlDtn8WkJrDQHjxQaWQkw4bdPztWktM=")
ka.loginResult()
#🔸Vigne
kb = LINETCR.LINE()
kb.login(token="Enlf1jnoeYeB9f3CZL43.ahMx8WG7MjoJNvXxZZCfKW.UX16MdIJAxsUzZsxcFbIMjA2qHd6MuaaWWRwMG8QKA0=")
kb.loginResult()
#🔸Satanichia
ko = LINETCR.LINE()
ko.login(token="En00lkz771SAXTUp6iaa.xwINC1s/Umx4wOsHkqVHsG.NQ4w3eCmr3UzE7Uv0DoTOWQOVtbSnWL6gXSgzom9eE4=") 
ko.loginResult()
#🔸Sagiri
ke = LINETCR.LINE()
ke.login(token="Ent9fbO3EQhTzjEM8aR8.EhF3TEklNgmGifU+iJODMa.vXIeab9rFo+PXNAMlAh02Rc2Z0666aa/cOdh2L3pOII=")
#sagiriasli__ke.login(token="EmLnJgCbROb2iNVYlW1a.faf8coH1ZHEEFhQt+Oz6wG.cSjW+wiwbPU0nQ61J6PNwDKawvLJeI0kTZK1XkbXcgw=")
ke.loginResult()
#🔸Erio
ku = LINETCR.LINE()
ku.login(token="EntuH8iYIDVbIHcEv4h3.XbawOba/1IEMt9uJ/RP7mW.GbMnNgfHMh5NuvaAnS0Wo7WQOP3zab5i4cyS7Br1V5E=")
ku.loginResult()
#🔸Mirai
kv = LINETCR.LINE()
kv.login(token="EnSrb9de2P53nrH9elJa.lt8pcTTQRbVkJgydiWCigG.k81EZ6vR7eNrboTKc/4/vVZB1pRnZDilMCpnyuelN24=")
kv.loginResult()
#🔸Sakura
kw = LINETCR.LINE()
kw.login(token="EnlMLcxOPtFYd4lphxX4.bewvvZj84AEMBtt17nh7ja.YxvIjLWvyrfn6XHPif+ZGeM7kOaxFpca/xoDkxsKFQM=")
kw.loginResult()
#🔸Mitsuki
kx = LINETCR.LINE()
kx.login(token="En5AQBfslTb5A3Nubnba.Q8JTvbxMieaWHGDZD+z7UG.54qgF8ZcFHePoC58J+a5zwOVaFzzSmLM4PBXj8HepI8=")
kx.loginResult()
#🔸ILLYA
#ky = LINETCR.LINE()
#ky.login(token="")
#ky.loginResult()

print "👋Welcome to emilia bot👍"
reload(sys)
sys.setdefaultencoding('utf-8')

helpMessage =""" 
＜<><><><><><><><><><><><><><>＞
[•=======================•]
≫ Creator
≫ Mid
≫ My mid
≫ All mid
≫ Mid @[Name]
≫ Check:[mid]
≫ Me
≫ Ginfo
≫ Group creator
≫ Pic group
≫ Gift
≫ Ram gift
≫ Rem gift
≫ Emilia gift
≫ Spam gift
≫ My bot
≫ Setlastpoint
≫ Viewlastseen
≫ Steal [SEND CONTACT]
≫ Pic @[NAME]
≫ Cover @[NAME]
≫ Image [TEXT]
≫ Music [TEXT]
≫ Getlirik [TEXT]
≫ Vn [TEXT]
≫ VnJa [TEXT]
≫ Video [TEXT]
[•=======================•]
               ADMIN ONLY
≫ Emilia groups
≫ Create group [TEXT]
≫ Invite group [GROUP NAME]
≫ Gn [TEXT]
≫ Open
≫ Close
≫ Url
≫ Invite [MID]
≫ Invite [SEND CONTACT]
≫ Hai
≫ Mention
≫ Clone @[NAME]
≫ Backup
≫ Backup all
≫ Kicker
≫ Kicker[1-12]
≫ [NAME BOT] join
≫ Leave
≫ Leave[1-12]
≫ Nk @[NAME]
≫ Nk [NAME]
≫ Zkick @[NAME]
≫ Hallo @[NAME]
≫ Ban @[NAME]
≫ Ban [SEND CONTACT]
≫ Kill
≫ Kill ban
≫ Unban @[NAME]
≫ Unban [SEND CONTACT]
≫ Ban list
[•=======================•]
              Group Settings
≫ Join on/off
≫ Contact on/off
≫ Share on/off
≫ Notifed on/off
≫ Tag on/off
≫ Like on/off
≫ Comment on/off
≫ Protect on/off
≫ QR on/off
≫ Cancel on/off
≫ Cancl on/off
＜<><><><><><><><><><><><><><>＞

"""

Setgroup ="""
≫ Protect Group - Protect on/off
≫ Protect Qr - Qr on/off
≫ Block invite - Cancel on/off
≫ Protect cancel - Cancl on/off
≫ Notifed - Notifed on/off
≫ Timeline - Share on/off
≫ Auto join - Join on/off
≫ Contact - Contact on/off
≫ Auto like - Like on/off
≫ Auto comment - Comment on/off
"""
KAC=[ki,kk,kc,ks,ka,kx]
KIK=[kb,ko,ke,ku,kv,kw]
mid = cl.getProfile().mid
Amid = ki.getProfile().mid
Bmid = kk.getProfile().mid
Cmid = kc.getProfile().mid
Dmid = ks.getProfile().mid
Emid = ka.getProfile().mid
Fmid = kb.getProfile().mid
Gmid = ko.getProfile().mid
Hmid = ke.getProfile().mid
Imid = ku.getProfile().mid
Jmid = kv.getProfile().mid
Kmid = kw.getProfile().mid
Lmid = kx.getProfile().mid
#Mmid = ky.getProfile().mid
 

mid = cl.getProfile().mid
Bots=[mid,Amid,Bmid,Cmid,Dmid,Emid,Fmid,Gmid,Hmid,Imid,Jmid,Kmid,Lmid]
admin=["u2a971cd821c4b526cae0816440aef0ad"]
Admin=["u2a971cd821c4b526cae0816440aef0ad"]
Creator=["u2a971cd821c4b526cae0816440aef0ad"]


wait = {
    'contact':False,
    'autoJoin':True,
    'autoCancel':{"on":True,"members":10},
    'leaveRoom':True,
    'timeline':True,
    'autoAdd':False ,
    'message':"よろしく\nThanks For Add Me..:v",
    "lang":"JP",
    "comment":"こんにちは\n『Auto Like By Emilia』\n\nhttp://line.me/ti/p/YQ2uhrdbZ2",
    "likeOn":True,
    "commentOn":True,
    "commentBlack":{},
    "wblack":False,
    "dblack":False,
    "blacklist":{},
    "wblacklist":False,
    "dblacklist":False,
    "ResponTag":True,
    "ProtectGroup":False,
    "ProtectQR":False,
    "Protectguest":False,
    "Protectcancel":False,
    "protectionOn":True,
    "atjointicket":True,
    "Notifed":False,
    "stealcontact":False,
    "pm":False,
    "pc":"pesan",
    "spam":False,
    "CHAT":False,
    }

wait2 = {
    'readPoint':{},
    'readMember':{},
    'setTime':{},
    'ROM':{}
    }

setTime = {}
setTime = wait2['setTime']

contact = cl.getProfile()
backup = cl.getProfile()
backup.displayName = contact.displayName
backup.statusMessage = contact.statusMessage
backup.pictureStatus = contact.pictureStatus

contact = ki.getProfile()
backupram = ki.getProfile()
backupram.displayName = contact.displayName
backupram.statusMessage = contact.statusMessage
backupram.pictureStatus = contact.pictureStatus

contact = kk.getProfile()
backuprem = kk.getProfile()
backuprem.displayName = contact.displayName
backuprem.statusMessage = contact.statusMessage
backuprem.pictureStatus = contact.pictureStatus

mulai = time.time()

def music(songname):
    params = {'songname':songname}
    url = 'http://ide.fdlrcn.com/workspace/yumi-apis/joox?' + urllib.urlencode(params)
    r = requests.get(url,verify=False).text
    data = json.loads(r)
    for song in data:
        return song[4]
        

def download_page(url):
    version = (3,0)
    cur_version = sys.version_info
    if cur_version >= version:  
        import urllib,request    
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"
            req = urllib,request.Request(url, headers = headers)
            resp = urllib,request.urlopen(req)
            respData = str(resp.read())
            return respData
        except Exception as e:
            print(str(e))
    else:                       
        import urllib2
        try:
            headers = {}
            headers['User-Agent'] = "Mozilla/5.0 (X11; Linux i686) AppleWebKit/537.17 (KHTML, like Gecko) Chrome/24.0.1312.27 Safari/537.17"
            req = urllib2.Request(url, headers = headers)
            response = urllib2.urlopen(req)
            page = response.read()
            return page
        except:
            return"Page Error tolol"
           
def _images_get_next_item(s):
    start_line = s.find('rg_di')
    if start_line == -1:    
        end_quote = 0
        link = "no_links"
        return link, end_quote
    else:
        start_line = s.find('"class="rg_meta"')
        start_content = s.find('"ou"',start_line+90)
        end_content = s.find(',"ow"',start_content-90)
        content_raw = str(s[start_content+6:end_content-1])
        return content_raw, end_content


def _images_get_all_items(page):
    items = []
    while True:
        item, end_content = _images_get_next_item(page)
        if item == "no_links":
            break
        else:
            items.append(item)     
            time.sleep(0.1)    
            page = page[end_content:]
    return items

def waktu(secs):
    mins, secs = divmod(secs,60)
    hours, mins = divmod(mins,60)
    return "%02d Jam %02d Menit %02d Detik" % (hours, mins, secs)


def cms(string, commands): #/XXX, >XXX, ;XXX, ^XXX, %XXX, $XXX...
    tex = ["+","@","/",">",";","^","%","$","＾","サテラ:","サテラ:","サテラ：","サテラ："] 
    for tex in tex:
        for command in commands:
            if string ==command:
                return True
          

def sendMessage(to, text, contentMetadata={}, contentType=0):
    mes = Message()
    mes.to, mes.from_ = to, profile.mid
    mes.text = text
    mes.contentType, mes.contentMetadata = contentType, contentMetadata
    if to not in messageReq:
        messageReq[to] = -1
    messageReq[to] += 1

def mention(to, nama):
    aa = ""
    bb = ""
    strt = int(14)
    akh = int(14)
    nm = nama
    for mm in nm:
      akh = akh + 2
      aa += """{"S":"""+json.dumps(str(strt))+""","E":"""+json.dumps(str(akh))+""","M":"""+json.dumps(mm)+"},"""
      strt = strt + 6
      akh = akh + 4
      bb += "\xe2\x95\xa0 @x \n"
    aa = (aa[:int(len(aa)-1)])
    msg = Message()
    msg.to = to
    msg.text = "\xe2\x95\x94\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\n"+bb+"\xe2\x95\x9a\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90\xe2\x95\x90"
    msg.contentMetadata ={'MENTION':'{"MENTIONEES":['+aa+']}','EMTVER':'4'}
    try:
       cl.sendMessage(msg)
    except Exception as error:
       print error 
#--------------------------------------------------------------#
def bot(op):
    try:
        if op.type == 0:
            return
#--------------------------------------------------------------#
        if op.type == 5:
            if wait["autoAdd"] == True:
                if (wait["message"] in [""," ","\n",None]):
                    pass
                else:
                    cl.sendText(op.param1,str(wait["message"]))
            if wait["autoAdd"] == True:
                ki.findAndAddContactsByMid(op.param1)
                if (wait["message"] in [""," ","\n",None]):
                    pass
                else:
                    ki.sendText(op.param1,str(wait["message"]))
            if wait["autoAdd"] == True:
                kk.findAndAddContactsByMid(op.param1)
                if (wait["message"] in [""," ","\n",None]):
                    pass
                else:
                    kk.sendText(op.param1,str(wait["message"]))
            if wait["autoAdd"] == True:
                kc.findAndAddContactsByMid(op.param1)
                if (wait["message"] in [""," ","\n",None]):
                    pass
                else:
                    kc.sendText(op.param1,str(wait["message"]))
            if wait["autoAdd"] == True:
                ka.findAndAddContactsByMid(op.param1)
                if (wait["message"] in [""," ","\n",None]):
                    pass
                else:
                    ks.sendText(op.param1,str(wait["message"])) 
            if wait["autoAdd"] == True:
                kb.findAndAddContactsByMid(op.param1)
                if (wait["message"] in [""," ","\n",None]):
                    pass
                else:
                    kb.sendText(op.param1,str(wait["message"]))
            if wait["autoAdd"] == True:
                ko.findAndAddContactsByMid(op.param1)
                if (wait["message"] in [""," ","\n",None]):
                    pass
                else:
                    ko.sendText(op.param1,str(wait["message"]))
            if wait["autoAdd"] == True:
                ke.findAndAddContactsByMid(op.param1)
                if (wait["message"] in [""," ","\n",None]):
                    pass
                else:
                    ko.sendText(op.param1,str(wait["message"]))
            if wait["autoAdd"] == True:
                ku.findAndAddContactsByMid(op.param1)
                if (wait["message"] in [""," ","\n",None]):
                    pass
                else:
                    ku.sendText(op.param1,str(wait["message"]))
            if wait["autoAdd"] == True:
                kv.findAndAddContactsByMid(op.param1)
                if (wait["message"] in [""," ","\n",None]):
                    pass
                else:
                    kv.sendText(op.param1,str(wait["message"]))
            if wait["autoAdd"] == True:
                kw.findAndAddContactsByMid(op.param1)
                if (wait["message"] in [""," ","\n",None]):
                    pass
                else:
                    kw.sendText(op.param1,str(wait["message"]))
            if wait["autoAdd"] == True:
                kx.findAndAddContactsByMid(op.param1)
                if (wait["message"] in [""," ","\n",None]):
                    pass
                else:
                    kx.sendText(op.param1,str(wait["message"]))
#======================================================# 
        #--------FUNGSI PROTECT QR KICK -------#
        if op.type == 11:
           if wait["ProtectQR"] == True:
               if op.param2 not in Bots:
                   G = cl.getGroup(op.param1)
                   G.preventJoinByTicket = True
                   random.choice(KAC).updateGroup(G)
                   c = Message(to=op.param1, from_=None, text=None, contentType=13)
                   c.contentMetadata={'mid':op.param2}
                   cl.sendMessage(c)
#======================================================# 
        #-------------Fungsi Block invite-----------#
        if op.type == 13:
           if wait["Protectguest"] == True:
               if op.param2 not in Bots:
                  group = cl.getGroup(op.param1)
                  gMembMids = [contact.mid for contact in group.invitee]
                  random.choice(KAC).cancelGroupInvitation(op.param1, gMembMids)
#--------------------------------------------------------------#
        if op.type == 19:
            if op.param3 in mid:
                if op.param2 in Amid:
                    G = ki.getGroup(op.param1)
                    G.preventJoinByTicket = False
                    ki.updateGroup(G)
                    Ticket = ki.reissueGroupTicket(op.param1)
                    cl.acceptGroupInvitationByTicket(op.param1,Ticket)
                    G.preventJoinByTicket = True
                    cl.updateGroup(G)
                    Ticket = cl.reissueGroupTicket(op.param1)

            if op.param3 in Amid:
                if op.param2 in Bmid:
                    X = kk.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    kk.updateGroup(X)
                    Ti = kk.reissueGroupTicket(op.param1)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    ki.updateGroup(X)
                    Ti = ki.reissueGroupTicket(op.param1)

            if op.param3 in Bmid:
                if op.param2 in Cmid:
                    X = kc.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    kc.updateGroup(X)
                    Ti = kc.reissueGroupTicket(op.param1)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    kk.updateGroup(X)
                    Ti = kk.reissueGroupTicket(op.param1)
            
            if op.param3 in Cmid:
                if op.param2 in Dmid:
                    X = ks.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    ks.updateGroup(X)
                    Ti = ks.reissueGroupTicket(op.param1)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    kc.updateGroup(X)
                    Ti = kc.reissueGroupTicket(op.param1)

            if op.param3 in Dmid:
                if op.param2 in Amid:
                    X = ki.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    ki.updateGroup(X)
                    Ti = ki.reissueGroupTicket(op.param1)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    ks.updateGroup(X)
                    Ti = ks.reissueGroupTicket(op.param1)
                
            if op.param3 in Emid:
                if op.param2 in Bmid:
                    X = kk.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    kk.updateGroup(X)
                    Ti = kk.reissueGroupTicket(op.param1)
                    ka.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    ka.updateGroup(X)
                    Ti = ka.reissueGroupTicket(op.param1)
                    
            if op.param3 in Fmid:
                if op.param2 in Cmid:
                    X = kc.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    kc.updateGroup(X)
                    Ti = kc.reissueGroupTicket(op.param1)
                    kb.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    kb.updateGroup(X)
                    Ti = kb.reissueGroupTicket(op.param1)

            if op.param3 in Gmid:
                if op.param2 in Emid:
                    X = ks.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    ks.updateGroup(X)
                    Ti = ks.reissueGroupTicket(op.param1)
                    ko.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    ko.updateGroup(X)
                    Ti = ko.reissueGroupTicket(op.param1)
                   
            if op.param3 in Hmid:
                if op.param2 in Amid:
                    X = ki.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    ki.updateGroup(X)
                    Ti = ki.reissueGroupTicket(op.param1)
                    ke.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    ke.updateGroup(X)
                    Ti = ke.reissueGroupTicket(op.param1)
                    
            if op.param3 in Imid:
                if op.param2 in Bmid:
                    X = kk.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    kk.updateGroup(X)
                    Ti = kk.reissueGroupTicket(op.param1)
                    ku.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    ku.updateGroup(X)
                    Ti = ku.reissueGroupTicket(op.param1)
                   
            if op.param3 in Jmid:
                if op.param2 in Cmid:
                    X = kc.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    kc.updateGroup(X)
                    Ti = kc.reissueGroupTicket(op.param1)
                    kv.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    kv.updateGroup(X)
                    Ti = kv.reissueGroupTicket(op.param1)
                    
            if op.param3 in Kmid:
                if op.param2 in Dmid:
                    X = ks.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    ks.updateGroup(X)
                    Ti = kc.reissueGroupTicket(op.param1)
                    kw.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    kw.updateGroup(X)
                    Ti = kw.reissueGroupTicket(op.param1)

            if op.param3 in Lmid:
                if op.param2 in Amid:
                    X = ki.getGroup(op.param1)
                    X.preventJoinByTicket = False
                    ki.updateGroup(X)
                    Ti = ki.reissueGroupTicket(op.param1)
                    kx.acceptGroupInvitationByTicket(op.param1,Ti)
                    X.preventJoinByTicket = True
                    kx.updateGroup(X)
                    Ti = kx.reissueGroupTicket(op.param1)
#--------------------------------------------------------------#
        if op.type == 13:
            print op.param1
            print op.param2
            print op.param3
            if mid in op.param3:
                G = cl.getGroup(op.param1)
                if wait["autoJoin"] == True:
                    if wait["autoCancel"]["on"] == True:
                        if len(G.members) <= wait["autoCancel"]["members"]:
                            cl.rejectGroupInvitation(op.param1)
                        else:
                            cl.acceptGroupInvitation(op.param1)
                    else:
                        cl.acceptGroupInvitation(op.param1)
                elif wait["autoCancel"]["on"] == True:
                    if len(G.members) <= wait["autoCancel"]["members"]:
                        cl.rejectGroupInvitation(op.param1)
            else:
                Inviter = op.param3.replace("",',')
                InviterX = Inviter.split(",")
                matched_list = []
                for tag in wait["blacklist"]:
                    matched_list+=filter(lambda str: str == tag, InviterX)
                if matched_list == []:
                    pass
                else:
                    cl.cancelGroupInvitation(op.param1, matched_list)
#======================================================# 
        # ----------------- NOTIFED LEAVE GROUP---#
        if op.type == 15:
            if wait["Notifed"] == True:
                if op.param2 in Bots:
                    return
                kc.sendText(op.param1,kc.getContact(op.param2).displayName + "\nJangan pergi meninggalkanku\n(´･ω･`)")
                print "MEMBER OUT GROUP"
#--------------------------------------------------------------#
        # ----------------- NOTIFED JOIN GROUP---#
        if op.type == 17:
            if wait["Notifed"] == True:
                if op.param2 in Bots:
                    return
                kc.sendText(op.param1,kc.getContact(op.param2).displayName + "\nWelcome Say\n↖(^ω^)↗")
                print "MEMBER HAS JOIN THE GROUP"
#--------------------------------------------------------------#
        #-----------------NOTIFED KICKOUT GROUP--------#
        if op.type == 19:
            if wait["Notifed"] == True:
                if op.param2 in Bots:
                    return
                kc.sendText(op.param1,kc.getContact(op.param2).displayName + "\nWahhh....Kikill!!!\n😱😱😱")
                print "MEMBER HAS KICKOUT FROM THE GROUP"
#======================================================# 
       #------------PROTECT GROUP KICKER----------#
        if op.type == 19:
            if wait["ProtectGroup"] == True:
                if op.param2 not in Bots:
                  G = cl.getGroup(op.param1)
                  random.choice(KIK).kickoutFromGroup(op.param1,[op.param2])
                  print error

        if op.type == 19:
           if op.param3 in admin:
              random.choice(KIK).kickoutFromGroup(op.param1,[op.param2])
              ki.inviteIntoGroup(op.param1,admin)
           else:
               pass

        if op.type == 19:
                if mid in op.param3:
                    if op.param2 in Bots:
                        pass
                    try:
                        random.choice(KIK).kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                        except:
                            print ("client Kick regulation or Because it does not exist in the group、\n["+op.param1+"]\nの\n["+op.param2+"]\nを蹴る事ができませんでした。\nブラックリストに追加します。")
                        if op.param2 in wait["blacklist"]:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True
                    G = random.choice(KAC).getGroup(op.param1)
                    G.preventJoinByTicket = False
                    random.choice(KAC).updateGroup(G)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    ka.acceptGroupInvitationByTicket(op.param1,Ti)
                    kb.acceptGroupInvitationByTicket(op.param1,Ti)
                    ko.acceptGroupInvitationByTicket(op.param1,Ti)
                    ke.acceptGroupInvitationByTicket(op.param1,Ti)
                    ku.acceptGroupInvitationByTicket(op.param1,Ti)
                    kv.acceptGroupInvitationByTicket(op.param1,Ti)
                    kw.acceptGroupInvitationByTicket(op.param1,Ti)
                    kx.acceptGroupInvitationByTicket(op.param1,Ti)
                   #kx.acceptGroupInvitationByTicket(op.param1,Ti)
                    X = cl.getGroup(op.param1)
                    X.preventJoinByTicket = True
                    cl.updateGroup(X)
                    Ti = cl.reissueGroupTicket(op.param1)
                    if op.param2 in wait["blacklist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True

                if Amid in op.param3:
                    if op.param2 in Bots:
                        pass
                    try:
                        random.choice(KIK).kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                        except:
                            print ("clientが蹴り規制orグループに存在しない為、\n["+op.param1+"]\nの\n["+op.param2+"]\nを蹴る事ができませんでした。\nブラックリストに追加します。")
                        if op.param2 in wait["blacklist"]:
                            pass
                        if op.param2 in wait["whitelist"]:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True

                    X = random.choice(KAC).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    ka.acceptGroupInvitationByTicket(op.param1,Ti)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    kb.acceptGroupInvitationByTicket(op.param1,Ti)
                    ko.acceptGroupInvitationByTicket(op.param1,Ti)
                    ke.acceptGroupInvitationByTicket(op.param1,Ti)
                    ku.acceptGroupInvitationByTicket(op.param1,Ti)
                    kv.acceptGroupInvitationByTicket(op.param1,Ti)
                    kw.acceptGroupInvitationByTicket(op.param1,Ti)
                    kx.acceptGroupInvitationByTicket(op.param1,Ti)
                    #ky.acceptGroupInvitationByTicket(op.param1,Ti)
                    G = ki.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    ki.updateGroup(G)
                    Ticket = ki.reissueGroupTicket(op.param1)
                    if op.param2 in wait["blacklist"]:
                        pass
                    if op.param2 in wait["whitelist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True
                        
                if Bmid in op.param3:
                    if op.param2 in Bots:
                        pass
                    try:
                        random.choice(KIK).kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                        except:
                            print ("clientが蹴り規制orグループに存在しない為、\n["+op.param1+"]\nの\n["+op.param2+"]\nを蹴る事ができませんでした。\nブラックリストに追加します。")
                        if op.param2 in wait["blacklist"]:
                            pass
                        if op.param2 in wait["whitelist"]:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True

                    X = random.choice(KAC).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    ka.acceptGroupInvitationByTicket(op.param1,Ti)
                    kb.acceptGroupInvitationByTicket(op.param1,Ti)
                    ko.acceptGroupInvitationByTicket(op.param1,Ti)
                    ke.acceptGroupInvitationByTicket(op.param1,Ti)
                    ku.acceptGroupInvitationByTicket(op.param1,Ti)
                    kv.acceptGroupInvitationByTicket(op.param1,Ti)
                    kw.acceptGroupInvitationByTicket(op.param1,Ti)
                    kx.acceptGroupInvitationByTicket(op.param1,Ti)
                    #ky.acceptGroupInvitationByTicket(op.param1,Ti)
                    G = kk.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    kk.updateGroup(G)
                    Ticket = kk.reissueGroupTicket(op.param1)
                    if op.param2 in wait["blacklist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True

                if Cmid in op.param3:
                    if op.param2 in Bots:
                        pass
                    try:
                        random.choice(KIK).kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                        except:
                            print ("clientが蹴り規制orグループに存在しない為、\n["+op.param1+"]\nの\n["+op.param2+"]\nを蹴る事ができませんでした。\nブラックリストに追加します。")
                        if op.param2 in wait["blacklist"]:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True

                    X = random.choice(KAC).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    ka.acceptGroupInvitationByTicket(op.param1,Ti)
                    kb.acceptGroupInvitationByTicket(op.param1,Ti)
                    ko.acceptGroupInvitationByTicket(op.param1,Ti)
                    ke.acceptGroupInvitationByTicket(op.param1,Ti)
                    ku.acceptGroupInvitationByTicket(op.param1,Ti)
                    kv.acceptGroupInvitationByTicket(op.param1,Ti)
                    kw.acceptGroupInvitationByTicket(op.param1,Ti)
                    kx.acceptGroupInvitationByTicket(op.param1,Ti)
                    #ky.acceptGroupInvitationByTicket(op.param1,Ti)
                    G = kc.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    kc.updateGroup(G)
                    Ticket = kc.reissueGroupTicket(op.param1)
                    if op.param2 in wait["blacklist"]:
                        pass
                    if op.param2 in wait["whitelist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True
                        
                if Dmid in op.param3:
                    if op.param2 in Bots:
                        pass
                    try:
                        random.choice(KIK).kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                        except:
                            print ("client Because it is not in the group or Because it does not exist in the group \n["+op.param1+"]\nOf\n["+op.param2+"]\n I could not kick \n Add it to the black list.")
                        if op.param2 in wait["blacklist"]:
                            pass
                        if op.param2 in wait["whitelist"]:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True

                    X = random.choice(KAC).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    ka.acceptGroupInvitationByTicket(op.param1,Ti)
                    kb.acceptGroupInvitationByTicket(op.param1,Ti)
                    ko.acceptGroupInvitationByTicket(op.param1,Ti)
                    ke.acceptGroupInvitationByTicket(op.param1,Ti)
                    ku.acceptGroupInvitationByTicket(op.param1,Ti)
                    kv.acceptGroupInvitationByTicket(op.param1,Ti)
                    kw.acceptGroupInvitationByTicket(op.param1,Ti)
                    kx.acceptGroupInvitationByTicket(op.param1,Ti)
                    #ky.acceptGroupInvitationByTicket(op.param1,Ti)
                    G = ks.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    ks.updateGroup(G)
                    Ticket = ks.reissueGroupTicket(op.param1)
                    if op.param2 in wait["blacklist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True

                if Emid in op.param3:
                    if op.param2 in Bots:
                        pass
                    try:
                        random.choice(KIK).kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                        except:
                            print ("client Because it is not in the group or Because it does not exist in the group \n["+op.param1+"]\nOf\n["+op.param2+"]\n I could not kick \n Add it to the black list.")
                        if op.param2 in wait["blacklist"]:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True

                    X = random.choice(KAC).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                    ka.acceptGroupInvitationByTicket(op.param1,Ti)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    kb.acceptGroupInvitationByTicket(op.param1,Ti)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    kb.acceptGroupInvitationByTicket(op.param1,Ti)
                    ko.acceptGroupInvitationByTicket(op.param1,Ti)
                    ke.acceptGroupInvitationByTicket(op.param1,Ti)
                    ku.acceptGroupInvitationByTicket(op.param1,Ti)
                    kv.acceptGroupInvitationByTicket(op.param1,Ti)
                    kw.acceptGroupInvitationByTicket(op.param1,Ti)
                    kx.acceptGroupInvitationByTicket(op.param1,Ti)
                    #ky.acceptGroupInvitationByTicket(op.param1,Ti)
                    G = ka.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    ka.updateGroup(G)
                    Ticket = ka.reissueGroupTicket(op.param1)
                    if op.param2 in wait["blacklist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True
                        

                if Fmid in op.param3:
                    if op.param2 in Bots:
                        pass
                    try:
                        random.choice(KIK).kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                        except:
                            print ("client Because it is not in the group or Because it does not exist in the group \n["+op.param1+"]\nOf\n["+op.param2+"]\n I could not kick \n Add it to the black list.")
                        if op.param2 in wait["blacklist"]:
                            pass
                        if op.param2 in wait["whitelist"]:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True

                    X = random.choice(KAC).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                    kb.acceptGroupInvitationByTicket(op.param1,Ti)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    ka.acceptGroupInvitationByTicket(op.param1,Ti)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    kb.acceptGroupInvitationByTicket(op.param1,Ti)
                    ko.acceptGroupInvitationByTicket(op.param1,Ti)
                    ke.acceptGroupInvitationByTicket(op.param1,Ti)
                    ku.acceptGroupInvitationByTicket(op.param1,Ti)
                    kv.acceptGroupInvitationByTicket(op.param1,Ti)
                    kw.acceptGroupInvitationByTicket(op.param1,Ti)
                    kx.acceptGroupInvitationByTicket(op.param1,Ti)
                    #ky.acceptGroupInvitationByTicket(op.param1,Ti)
                    G = kb.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    kb.updateGroup(G)
                    Ticket = kb.reissueGroupTicket(op.param1)
                    if op.param2 in wait["blacklist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True

                if Gmid in op.param3:
                    if op.param2 in Bots:
                        pass
                    try:
                        random.choice(KIK).kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                        except:
                            print ("clientが蹴り規制orグループに存在しない為、\n["+op.param1+"]\nの\n["+op.param2+"]\nを蹴る事ができませんでした。\nブラックリストに追加します。")
                        if op.param2 in wait["blacklist"]:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True

                    X = random.choice(KAC).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                    ko.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    ka.acceptGroupInvitationByTicket(op.param1,Ti)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ke.acceptGroupInvitationByTicket(op.param1,Ti)
                    kb.acceptGroupInvitationByTicket(op.param1,Ti)
                    ku.acceptGroupInvitationByTicket(op.param1,Ti)
                    kv.acceptGroupInvitationByTicket(op.param1,Ti)
                    kw.acceptGroupInvitationByTicket(op.param1,Ti)
                    kx.acceptGroupInvitationByTicket(op.param1,Ti)
                    #ky.acceptGroupInvitationByTicket(op.param1,Ti)
                    G = ko.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    ko.updateGroup(G)
                    Ticket = ko.reissueGroupTicket(op.param1)
                    if op.param2 in wait["blacklist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True                    

                if Hmid in op.param3:
                    if op.param2 in Bots:
                        pass
                    try:
                        random.choice(KIK).kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                        except:
                            print ("clientが蹴り規制orグループに存在しない為、\n["+op.param1+"]\nの\n["+op.param2+"]\nを蹴る事ができませんでした。\nブラックリストに追加します。")
                        if op.param2 in wait["blacklist"]:
                            pass 
                        else:
                            wait["blacklist"][op.param2] = True

                    X = random.choice(KAC).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                    ke.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    ka.acceptGroupInvitationByTicket(op.param1,Ti)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ku.acceptGroupInvitationByTicket(op.param1,Ti)
                    kv.acceptGroupInvitationByTicket(op.param1,Ti)
                    kw.acceptGroupInvitationByTicket(op.param1,Ti)
                    kx.acceptGroupInvitationByTicket(op.param1,Ti)
                    #ky.acceptGroupInvitationByTicket(op.param1,Ti)
                    G = ke.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    ke.updateGroup(G)
                    Ticket = ke.reissueGroupTicket(op.param1)
                    if op.param2 in wait["blacklist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True      
              
                if Imid in op.param3:
                    if op.param2 in Bots:
                        pass
                    try:
                        random.choice(KIK).kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                        except:
                            print ("clientが蹴り規制orグループに存在しない為、\n["+op.param1+"]\nの\n["+op.param2+"]\nを蹴る事ができませんでした。\nブラックリストに追加します。")
                        if op.param2 in wait["blacklist"]:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True

                    X = random.choice(KAC).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                    ku.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    ka.acceptGroupInvitationByTicket(op.param1,Ti)
                    kb.acceptGroupInvitationByTicket(op.param1,Ti)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    kv.acceptGroupInvitationByTicket(op.param1,Ti)
                    kw.acceptGroupInvitationByTicket(op.param1,Ti)
                    kx.acceptGroupInvitationByTicket(op.param1,Ti)
                    #ky.acceptGroupInvitationByTicket(op.param1,Ti)
                    G = ku.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    ku.updateGroup(G)
                    Ticket = ku.reissueGroupTicket(op.param1)
                    if op.param2 in wait["blacklist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True                    

                if Jmid in op.param3:
                    if op.param2 in Bots:
                        pass
                    try:
                        random.choice(KIK).kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                        except:
                            print ("clientが蹴り規制orグループに存在しない為、\n["+op.param1+"]\nの\n["+op.param2+"]\nを蹴る事ができませんでした。\nブラックリストに追加します。")
                        if op.param2 in wait["blacklist"]:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True

                    X = random.choice(KAC).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                    kv.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    ka.acceptGroupInvitationByTicket(op.param1,Ti)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ko.acceptGroupInvitationByTicket(op.param1,Ti)
                    ke.acceptGroupInvitationByTicket(op.param1,Ti)
                    ku.acceptGroupInvitationByTicket(op.param1,Ti)
                    kw.acceptGroupInvitationByTicket(op.param1,Ti)
                    kx.acceptGroupInvitationByTicket(op.param1,Ti)
                    #ky.acceptGroupInvitationByTicket(op.param1,Ti)
                    G = kv.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    kv.updateGroup(G)
                    Ticket = kv.reissueGroupTicket(op.param1)
                    if op.param2 in wait["blacklist"]:
                        pass 
                    else:
                        wait["blacklist"][op.param2] = True                    

                if Kmid in op.param3:
                    if op.param2 in Bots:
                        pass
                    try:
                        random.choice(KIK).kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                        except:
                            print ("clientが蹴り規制orグループに存在しない為、\n["+op.param1+"]\nの\n["+op.param2+"]\nを蹴る事ができませんでした。\nブラックリストに追加します。")
                        if op.param2 in wait["blacklist"]:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True

                    X = random.choice(KAC).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                    kw.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    ka.acceptGroupInvitationByTicket(op.param1,Ti)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ko.acceptGroupInvitationByTicket(op.param1,Ti)
                    ke.acceptGroupInvitationByTicket(op.param1,Ti)
                    ku.acceptGroupInvitationByTicket(op.param1,Ti)
                    kv.acceptGroupInvitationByTicket(op.param1,Ti)
                    kx.acceptGroupInvitationByTicket(op.param1,Ti)
                    #ky.acceptGroupInvitationByTicket(op.param1,Ti)
                    G = kw.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    kw.updateGroup(G)
                    Ticket = kw.reissueGroupTicket(op.param1)
                    if op.param2 in wait["blacklist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True                    

                if Lmid in op.param3:
                    if op.param2 in Bots:
                        pass
                    try:
                        random.choice(KIK).kickoutFromGroup(op.param1,[op.param2])
                    except:
                        try:
                            random.choice(KAC).kickoutFromGroup(op.param1,[op.param2])
                        except:
                            print ("clientが蹴り規制orグループに存在しない為、\n["+op.param1+"]\nの\n["+op.param2+"]\nを蹴る事ができませんでした。\nブラックリストに追加します。")
                        if op.param2 in wait["blacklist"]:
                            pass
                        else:
                            wait["blacklist"][op.param2] = True

                    X = random.choice(KAC).getGroup(op.param1)
                    X.preventJoinByTicket = False
                    random.choice(KAC).updateGroup(X)
                    Ti = random.choice(KAC).reissueGroupTicket(op.param1)
                    kx.acceptGroupInvitationByTicket(op.param1,Ti)
                    kw.acceptGroupInvitationByTicket(op.param1,Ti)
                    ki.acceptGroupInvitationByTicket(op.param1,Ti)
                    kk.acceptGroupInvitationByTicket(op.param1,Ti)
                    kc.acceptGroupInvitationByTicket(op.param1,Ti)
                    ks.acceptGroupInvitationByTicket(op.param1,Ti)
                    ka.acceptGroupInvitationByTicket(op.param1,Ti)
                    cl.acceptGroupInvitationByTicket(op.param1,Ti)
                    ko.acceptGroupInvitationByTicket(op.param1,Ti)
                    ke.acceptGroupInvitationByTicket(op.param1,Ti)
                    ku.acceptGroupInvitationByTicket(op.param1,Ti)
                    kv.acceptGroupInvitationByTicket(op.param1,Ti)
                    #ky.acceptGroupInvitationByTicket(op.param1,Ti)
                    G = kx.getGroup(op.param1)
                    G.preventJoinByTicket = True
                    kx.updateGroup(G)
                    Ticket = kx.reissueGroupTicket(op.param1)
                    if op.param2 in wait["blacklist"]:
                        pass
                    else:
                        wait["blacklist"][op.param2] = True                    
#--------------------------------------------------------------#
        if op.type == 13:
            if mid in op.param3:
                G = cl.getGroup(op.param1)
                if wait["autoJoin"] == True:
                    if wait["autoCancel"]["on"] == True:
                        if len(G.members) <= wait["autoCancel"]["members"]:
                            cl.rejectGroupInvitation(op.param1)
                        else:
                            cl.acceptGroupInvitation(op.param1)
                    else:
                        cl.acceptGroupInvitation(op.param1)
                elif wait["autoCancel"]["on"] == True:
                    if len(G.members) <= wait["autoCancel"]["members"]:
                        cl.rejectGroupInvitation(op.param1)
            else:
                Inviter = op.param3.replace("",',')
                InviterX = Inviter.split(",")
                matched_list = []
                for tag in wait["blacklist"]:
                    matched_list+=filter(lambda str: str == tag, InviterX)
                if matched_list == []:
                    pass
                else:
                    cl.cancelGroupInvitation(op.param1, matched_list)
#--------------------------------------------------------------#
            if Amid in op.param3:
                G = ki.getGroup(op.param1)
                if wait["autoJoin"] == True:
                    if wait["autoCancel"]["on"] == True:
                        if len(G.members) <= wait["autoCancel"]["members"]:
                            ki.rejectGroupInvitation(op.param1)
                        else:
                            ki.acceptGroupInvitation(op.param1)
                    else:
                        ki.acceptGroupInvitation(op.param1)
            if Bmid in op.param3:
                G = kk.getGroup(op.param1)
                if wait["autoJoin"] == True:
                    if wait["autoCancel"]["on"] == True:
                        if len(G.members) <= wait["autoCancel"]["members"]:
                            kk.rejectGroupInvitation(op.param1)
                        else:
                            kk.acceptGroupInvitation(op.param1)
                    else:
                        kk.acceptGroupInvitation(op.param1)
            if Cmid in op.param3:
                G = kc.getGroup(op.param1)
                if wait["autoJoin"] == True:
                    if wait["autoCancel"]["on"] == True:
                        if len(G.members) <= wait["autoCancel"]["members"]:
                            kc.rejectGroupInvitation(op.param1)
                        else:
                            kc.acceptGroupInvitation(op.param1)
                    else:
                        kc.acceptGroupInvitation(op.param1)
                elif wait["autoCancel"]["on"] == True:
                    if len(G.members) <= wait["autoCancel"]["members"]:
                        cl.rejectGroupInvitation(op.param1)
            else:
                Inviter = op.param3.replace("",',')
                InviterX = Inviter.split(",")
                matched_list = []
                for tag in wait["blacklist"]:
                    matched_list+=filter(lambda str: str == tag, InviterX)
                if matched_list == []:
                    pass
                else:
                    ki.cancelGroupInvitation(op.param1, matched_list)
        if op.type == 22:
            if wait["leaveRoom"] == True:
                cl.leaveRoom(op.param1)
                ki.leaveRoom(op.param1)
                kk.leaveRoom(op.param1)
                kc.leaveRoom(op.param1)
                ks.leaveRoom(op.param1)
                ka.leaveRoom(op.param1)
                kb.leaveRoom(op.param1)
                ko.leaveRoom(op.param1)
                ke.leaveRoom(op.param1)
                ku.leaveRoom(op.param1)
                kv.leaveRoom(op.param1)
                kw.leaveRoom(op.param1)
                kx.leaveRoom(op.param1)
        if op.type == 24:
            if wait["leaveRoom"] == True:
                cl.leaveRoom(op.param1)
                ki.leaveRoom(op.param1)
                kk.leaveRoom(op.param1)
                kc.leaveRoom(op.param1)
                ks.leaveRoom(op.param1)
                ka.leaveRoom(op.param1)
                kb.leaveRoom(op.param1)
                ko.leaveRoom(op.param1)
                ke.leaveRoom(op.param1)
                ku.leaveRoom(op.param1)
                kv.leaveRoom(op.param1)
                kw.leaveRoom(op.param1)
                kx.leaveRoom(op.param1) 
#=================================================================================
        if op.type == 26:
            msg = op.message
            if msg.toType == 0:
                msg.to = msg.from_
                if msg.from_ == profile.mid:
                    if "join:" in msg.text:
                        list_ = msg.text.split(":")
                        try:
                            cl.acceptGroupInvitationByTicket(list_[1],list_[2])
                            X = cl.getGroup(list_[1])
                            X.preventJoinByTicket = True
                            cl.updateGroup(X)
                        except:
                            cl.sendText(msg.to,"error")
                    if msg.text in "@􀨁􀨁􀄆􏿿猫􀂳E􀂳‮􀂳🕕a􀂳i􀂳l􀂳i􀂳m":
                      try:
                          if wait["ResponTag"] == True:
                             panggil = msg.text.replace("@􀨁􀨁􀄆􏿿猫􀂳E􀂳‮􀂳🕕a􀂳i􀂳l􀂳i􀂳m","")
                             cl.sendText(msg.to,"Cie Ngetag:v")
                      except Exception as error:
                        print error
#======================================================# 
        #------FUNGSI PROTECT CANCEL------#
        if op.type == 32:
            if wait["Protectcancel"] == True:
            	if op.param2 not in Bots:
                    G = cl.getGroup(op.param1)
                    random.choice(KIK).kickoutFromGroup(op.param1,[op.param2])
                    ki.inviteIntoGroup(op.param1,op.param3)
#======================================================# 
            if msg.toType == 1:
                if wait["leaveRoom"] == True:
                    cl.leaveRoom(msg.to)
                    ki.leaveRoom(msg.to)
                    kk.leaveRoom(msg.to)
                    kc.leaveRoom(msg.to)
                    ks.leaveRoom(msg.to)
                    ka.leaveRoom(msg.to)
                    kb.leaveRoom(msg.to)
                    ko.leaveRoom(msg.to)
                    ke.leaveRoom(msg.to)
                    ku.leaveRoom(msg.to)
                    kv.leaveRoom(msg.to)
                    kw.leaveRoom(msg.to)
                    kx.leaveRoom(msg.to)
#--------------------------------------------------------
            if msg.contentType == 16:
                url = msg.contentMetadata("line://home/post?userMid="+mid+"&postId="+"new_post")
                cl.like(url[25:58], url[66:], likeType=1001)
#--------------------------------------------------------
        if op.type == 25:
            msg = op.message
            if msg.contentType == 13:
#--------------------------------------------------------
               if wait["wblack"] == True:
                    if msg.contentMetadata["mid"] in wait["commentBlack"]:
                        cl.sendText(msg.to,"already")
                        wait["wblack"] = False
                    else:
                        wait["commentBlack"][msg.contentMetadata["mid"]] = True
                        wait["wblack"] = False
                        cl.sendText(msg.to,"decided not to comment")
#--------------------------------------------------------
               elif wait["dblack"] == True:
                   if msg.contentMetadata["mid"] in wait["commentBlack"]:
                        del wait["commentBlack"][msg.contentMetadata["mid"]]
                        cl.sendText(msg.to,"deleted")
                        wait["dblack"] = False
                   else:
                        wait["dblack"] = False
                        cl.sendText(msg.to,"It is not in the black list")
#--------------------------------------------------------
               elif wait["wblacklist"] == True:
                   if msg.contentMetadata["mid"] in wait["blacklist"]:
                        cl.sendText(msg.to,"already")
                        wait["wblacklist"] = False
                   else:
                        wait["blacklist"][msg.contentMetadata["mid"]] = True
                        wait["wblacklist"] = False
                        cl.sendText(msg.to,"aded")
#--------------------------------------------------------
               elif wait["dblacklist"] == True:
                   if msg.contentMetadata["mid"] in wait["blacklist"]:
                        del wait["blacklist"][msg.contentMetadata["mid"]]
                        cl.sendText(msg.to,"deleted")
                        wait["dblacklist"] = False

                   else:
                        wait["dblacklist"] = False
                        cl.sendText(msg.to,"It is not in the black list")
#--------------------------------------------------------
               elif wait["contact"] == True:
                    msg.contentType = 0
                    cl.sendText(msg.to,msg.contentMetadata["mid"])
                    if 'displayName' in msg.contentMetadata:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        try:
                            cu = cl.channel.getCover(msg.contentMetadata["mid"])
                        except:
                            cu = ""
                        cl.sendText(msg.to,"[displayName]:\n" + msg.contentMetadata["displayName"] + "\n[mid]:\n" + msg.contentMetadata["mid"] + "\n[statusMessage]:\n" + contact.statusMessage + "\n[pictureStatus]:\nhttp://dl.profile.line-cdn.net/" + contact.pictureStatus + "\n[coverURL]:\n" + str(cu))
                    else:
                        contact = cl.getContact(msg.contentMetadata["mid"])
                        try:
                            cu = cl.channel.getCover(msg.contentMetadata["mid"])
                        except:
                            cu = ""
                        cl.sendText(msg.to,"[displayName]:\n" + contact.displayName + "\n[mid]:\n" + msg.contentMetadata["mid"] + "\n[statusMessage]:\n" + contact.statusMessage + "\n[pictureStatus]:\nhttp://dl.profile.line-cdn.net/" + contact.pictureStatus + "\n[coverURL]:\n" + str(cu))
#--------------------------------------------------------
            elif msg.contentType == 16:
                if wait["timeline"] == True:
                    msg.contentType = 0
                    if wait["lang"] == "JP":
                        msg.text = "post URL\n" + msg.contentMetadata["postEndUrl"]
                    else:
                        msg.text = "URLâ†’\n" + msg.contentMetadata["postEndUrl"]
                    cl.sendText(msg.to,msg.text)
#--------------------------------------------------------
            elif msg.text is None:
                return
#--------------------------------------------------------
            elif msg.text in ["Help"]:
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,helpMessage)
                else:
                    cl.sendText(msg.to,helpt)
#--------------------------------------------------------
            elif msg.text in ["Set"]:
              if msg.from_ in admin:
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,Setgroup)
                else:
                    cl.sendText(msg.to,Sett)
#======================================================# 
                    #--------------FUNGSI CHANGE GROUP NAME----------#
            elif ("Gn " in msg.text):
              if msg.from_ in admin:
                if msg.toType == 2:
                    X = cl.getGroup(msg.to)
                    X.name = msg.text.replace("Gn ","")
                    cl.updateGroup(X)
                else:
                    cl.sendText(msg.to,"It can't be used besides the group.")
#--------------------------------------------------------
            elif ("Ram gn " in msg.text):
              if msg.from_ in admin:
                if msg.toType == 2:
                    X = cl.getGroup(msg.to)
                    X.name = msg.text.replace("Ram gn ","")
                    ki.updateGroup(X)
                else:
                    ki.sendText(msg.to,"It can't be used besides the group.")
#--------------------------------------------------------
            elif ("Rem gn " in msg.text):
              if msg.from_ in admin:
                if msg.toType == 2:
                    X = cl.getGroup(msg.to)
                    X.name = msg.text.replace("Rem gn ","")
                    kk.updateGroup(X)
                else:
                    kk.sendText(msg.to,"It can't be used besides the group.")
#--------------------------------------------------------
            elif ("Emilia gn " in msg.text):
              if msg.from_ in admin:
                if msg.toType == 2:
                    X = cl.getGroup(msg.to)
                    X.name = msg.text.replace("Emilia gn ","")
                    kc.updateGroup(X)
                else:
                    kc.sendText(msg.to,"It can't be used besides the group.")
#======================================================# 
                    #------------FUNGSI KICK BY (MID]----------#
            elif "Kick " in msg.text:
              if msg.from_ in admin:
                midd = msg.text.replace("Kick ","")
                cl.kickoutFromGroup(msg.to,[midd])
#--------------------------------------------------------
            elif "Ram kick " in msg.text:
              if msg.from_ in admin:
                midd = msg.text.replace("Ram kick ","")
                ki.kickoutFromGroup(msg.to,[midd])
#--------------------------------------------------------
            elif "Rem kick " in msg.text:
              if msg.from_ in admin:
                midd = msg.text.replace("Rem kick ","")
                kk.kickoutFromGroup(msg.to,[midd])
#--------------------------------------------------------
            elif "Emilia kick " in msg.text:
              if msg.from_ in admin:
                midd = msg.text.replace("Emilia kick ","")
                kc.kickoutFromGroup(msg.to,[midd])
#--------------------------------------------------------
            elif "Raphi kick " in msg.text:
              if msg.from_ in admin:
                midd = msg.text.replace("Raphi kick ","")
                ks.kickoutFromGroup(msg.to,[midd])
#--------------------------------------------------------
            elif "Gabriel kick " in msg.text:
              if msg.from_ in admin:
                midd = msg.text.replace("Gabriel kick ","")
                ka.kickoutFromGroup(msg.to,[midd])
#--------------------------------------------------------
            elif "Vigne kick " in msg.text:
              if msg.from_ in admin:
                midd = msg.text.replace("Vigne kick ","")
                kb.kickoutFromGroup(msg.to,[midd])
#--------------------------------------------------------
            elif "Satania kick " in msg.text:
              if msg.from_ in admin:
                midd = msg.text.replace("Satania kick ","")
                ko.kickoutFromGroup(msg.to,[midd])
#--------------------------------------------------------
            elif "Sagiri kick " in msg.text:
              if msg.from_ in admin:
                midd = msg.text.replace("Sagiri kick ","")
                ke.kickoutFromGroup(msg.to,[midd])
#--------------------------------------------------------
            elif "Erio kick " in msg.text:
              if msg.from_ in admin:
                midd = msg.text.replace("Erio kick ","")
                ku.kickoutFromGroup(msg.to,[midd])
#--------------------------------------------------------
            elif "Mirai kick " in msg.text:
              if msg.from_ in admin:
                midd = msg.text.replace("Mirai kick ","")
                kv.kickoutFromGroup(msg.to,[midd])
#--------------------------------------------------------
            elif "Sakura kick " in msg.text:
              if msg.from_ in admin:
                midd = msg.text.replace("Sakura kick ","")
                kw.kickoutFromGroup(msg.to,[midd])
#--------------------------------------------------------
            elif "Mitsuki kick " in msg.text:
              if msg.from_ in admin:
                midd = msg.text.replace("Mitsuki kick ","")
                kx.kickoutFromGroup(msg.to,[midd])
#======================================================# 
                #-----------FUNGSI INVITE BY MID-------#
            elif "Invite " in msg.text:
              if msg.from_ in admin:
                midd = msg.text.replace("Invite ","")
                cl.findAndAddContactsByMid(midd)
                cl.inviteIntoGroup(msg.to,[midd])
#--------------------------------------------------------
            elif "Ram invite " in msg.text:
              if msg.from_ in admin:
                midd = msg.text.replace("Ram invite ","")
                ki.findAndAddContactsByMid(midd)
                ki.inviteIntoGroup(msg.to,[midd])
#--------------------------------------------------------
            elif "Rem invite " in msg.text:
              if msg.from_ in admin:
                midd = msg.text.replace("Rem invite ","")
                kk.findAndAddContactsByMid(midd)
                kk.inviteIntoGroup(msg.to,[midd])
#--------------------------------------------------------
            elif "Emilia invite " in msg.text:
              if msg.from_ in admin:
                midd = msg.text.replace("Emilia invite ","")
                kc.findAndAddContactsByMid(midd)
                kc.inviteIntoGroup(msg.to,[midd])
#--------------------------------------------------------
            elif "Raphi invite " in msg.text:
              if msg.from_ in admin:
                midd = msg.text.replace("Raphi invite ","")
                ks.findAndAddContactsByMid(midd)
                ks.inviteIntoGroup(msg.to,[midd])
#--------------------------------------------------------
            elif "Gabriel invite " in msg.text:
              if msg.from_ in admin:
                midd = msg.text.replace("Gabriel invite ","")
                ka.findAndAddContactsByMid(midd)
                ka.inviteIntoGroup(msg.to,[midd])
#--------------------------------------------------------
            elif "Vigne invite " in msg.text:
              if msg.from_ in admin:
                midd = msg.text.replace("Vigne invite ","")
                kb.findAndAddContactsByMid(midd)
                kb.inviteIntoGroup(msg.to,[midd])
#--------------------------------------------------------
            elif "Satania invite " in msg.text:
              if msg.from_ in admin:
                midd = msg.text.replace("Satania invite ","")
                ko.findAndAddContactsByMid(midd)
                ko.inviteIntoGroup(msg.to,[midd])
#--------------------------------------------------------
            elif "Sagiri invite " in msg.text:
              if msg.from_ in admin:
                midd = msg.text.replace("Sagiri invite ","")
                ke.findAndAddContactsByMid(midd)
                ke.inviteIntoGroup(msg.to,[midd])
#--------------------------------------------------------
            elif "Erio invite " in msg.text:
              if msg.from_ in admin:
                midd = msg.text.replace("Erio invite ","")
                ku.findAndAddContactsByMid(midd)
                ku.inviteIntoGroup(msg.to,[midd])
#--------------------------------------------------------
            elif "Mirai invite " in msg.text:
              if msg.from_ in admin:
                midd = msg.text.replace("Mirai invite ","")
                kv.findAndAddContactsByMid(midd)
                kv.inviteIntoGroup(msg.to,[midd])
#--------------------------------------------------------
            elif "Sakura invite " in msg.text:
              if msg.from_ in admin:
                midd = msg.text.replace("Sakura invite ","")
                kw.findAndAddContactsByMid(midd)
                kw.inviteIntoGroup(msg.to,[midd])
#======================================================# 
            elif ("Reinvite " in msg.text):
               if msg.from_ in admin:
                   targets = []
                   key = eval(msg.contentMetadata["MENTION"])
                   key["MENTIONEES"] [0] ["M"]
                   for x in key["MENTIONEES"]:
                       targets.append(x["M"])
                   for target in targets:
                       try:
                           cl.kickoutFromGroup(msg.to,[target])
                           cl.findAndAddContactsByMENTION(key)
                           cl.inviteIntoGroup(msg.to,[key])
                           print (msg.to,[g.mid])
                       except:
                           pass
#======================================================# 
            elif msg.text in ["Me"]:
                msg.contentType = 13
                msg.contentMetadata = {'mid': msg.from_}
                cl.sendMessage(msg)
            elif msg.text in ["Creator"]:
                msg.contentType = 13
                msg.contentMetadata = {'mid': Creator}
                cl.sendMessage(msg)
                cl.sendText(msg.to, "👆My Creator :v")
            elif msg.text in ["Mybot"]:
              if msg.from_ in Creator:
                msg.contentType = 13
                msg.contentMetadata = {'mid': mid}
                cl.sendMessage(msg)

                msg.contentType = 13
                msg.contentMetadata = {'mid': Amid}
                cl.sendMessage(msg)

                msg.contentType = 13
                msg.contentMetadata = {'mid': Bmid}
                cl.sendMessage(msg)

                msg.contentType = 13
                msg.contentMetadata = {'mid': Cmid}
                cl.sendMessage(msg)
                
                msg.contentType = 13
                msg.contentMetadata = {'mid': Dmid}
                cl.sendMessage(msg)
                
                msg.contentType = 13
                msg.contentMetadata = {'mid': Emid}
                cl.sendMessage(msg)
                
                msg.contentType = 13
                msg.contentMetadata = {'mid': Fmid}
                cl.sendMessage(msg)
                
                msg.contentType = 13
                msg.contentMetadata = {'mid': Gmid}
                cl.sendMessage(msg)
                
                msg.contentType = 13
                msg.contentMetadata = {'mid': Hmid}
                cl.sendMessage(msg)
                
                msg.contentType = 13
                msg.contentMetadata = {'mid': Imid}
                cl.sendMessage(msg)
                
                msg.contentType = 13
                msg.contentMetadata = {'mid': Jmid}
                cl.sendMessage(msg)
                
                msg.contentType = 13
                msg.contentMetadata = {'mid': Kmid}
                cl.sendMessage(msg)
                
                msg.contentType = 13
                msg.contentMetadata = {'mid': Lmid}
                cl.sendMessage(msg)
#======================================================# 
            elif msg.text in ["gift","Gift","Gip"]:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': 'db0fbec9-6d9f-4ff0-adee-f671b71cb0be',
                                    'PRDTYPE': 'THEME',
                                    'MSGTPL': '6'}
                msg.text = None
                cl.sendMessage(msg)
            elif msg.text in ["ram gift","Ram gift","."]:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': '749ecd23-e038-4cd5-acac-23d46f4277c8',
                                    'PRDTYPE': 'THEME',
                                    'MSGTPL': '7'}
                msg.text = None
                ki.sendMessage(msg)
            elif msg.text in ["rem gift","Rem gift","K2 gift"]:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': 'db0fbec9-6d9f-4ff0-adee-f671b71cb0be',
                                    'PRDTYPE': 'THEME',
                                    'MSGTPL': '8'}
                msg.text = None
                kk.sendMessage(msg)
            elif msg.text in ["Emilia gift","emilia gift","K3 gift"]:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': '517174f2-1545-43b9-a28f-5777154045a6',
                                    'PRDTYPE': 'THEME',
                                    'MSGTPL': '11'}
                msg.text = None
                kc.sendMessage(msg)
            elif msg.text in ["Spam gift","All gift","ん"]:
                msg.contentType = 9
                msg.contentMetadata={'PRDID': '3b92ccf5-54d3-4765-848f-c9ffdc1da020',
                                    'PRDTYPE': 'THEME',
                                    'MSGTPL': '6'}
                msg.text = None
                ki.sendMessage(msg)
                kk.sendMessage(msg)
                kc.sendMessage(msg)
                ka.sendMessage(msg)
                ks.sendMessage(msg)
                kb.sendMessage(msg)
                ko.sendMessage(msg)
                ke.sendMessage(msg)
                ku.sendMessage(msg)
                kv.sendMessage(msg)
                kw.sendMessage(msg)
                kx.sendMessage(msg)
                ki.sendMessage(msg)
                kk.sendMessage(msg)
                kc.sendMessage(msg)
                ka.sendMessage(msg)
                ks.sendMessage(msg)
                kb.sendMessage(msg)
                ko.sendMessage(msg)
                ke.sendMessage(msg)
                ku.sendMessage(msg)
                kv.sendMessage(msg)
                kw.sendMessage(msg)
                kx.sendMessage(msg)
                ki.sendMessage(msg)
                kk.sendMessage(msg)
                kc.sendMessage(msg)
                ka.sendMessage(msg)
                ks.sendMessage(msg)
                kb.sendMessage(msg)
                ko.sendMessage(msg)
                ke.sendMessage(msg)
                ku.sendMessage(msg)
                kv.sendMessage(msg)
                kw.sendMessage(msg)
                kx.sendMessage(msg)
#======================================================# 
            elif "Bc: " in msg.text:
              if msg.from_ in Creator:
		bc = msg.text.replace("Bc: ","")
		gid = cl.getGroupIdsJoined()
		for i in gid:
		    cl.sendText(i,"[•=====BROADCAST=====•]\n\n"+bc+"\n\n==============")
		cl.sendText(msg.to,"Yosh \n Done。")
#======================================================# 
            elif msg.text in ["Cancel","cancel"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    X = cl.getGroup(msg.to)
                    if X.invitee is not None:
                        gInviMids = [contact.mid for contact in X.invitee]
                        cl.cancelGroupInvitation(msg.to, gInviMids)
                    else:
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"No one is inviting")
                        else:
                            cl.sendText(msg.to,"Sorry, nobody absent")
                else:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Can not be used outside the group")
                    else:
                        cl.sendText(msg.to,"Not for use less than group")
#--------------------------------------------------------
            elif msg.text in ["Ram cancel","K1 cancel"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    X = ki.getGroup(msg.to)
                    if X.invitee is not None:
                        gInviMids = [contact.mid for contact in X.invitee]
                        ki.cancelGroupInvitation(msg.to, gInviMids)
                    else:
                        if wait["lang"] == "JP":
                            ki.sendText(msg.to,"No one is inviting")
                        else:
                            ki.sendText(msg.to,"Sorry, nobody absent")
                else:
                    if wait["lang"] == "JP":
                        ki.sendText(msg.to,"Can not be used outside the group")
                    else:
                        ki.sendText(msg.to,"Not for use less than group")
#--------------------------------------------------------
            elif msg.text in ["Rem cancel","K2 cancel"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    X = kk.getGroup(msg.to)
                    if X.invitee is not None:
                        gInviMids = [contact.mid for contact in X.invitee]
                        kk.cancelGroupInvitation(msg.to, gInviMids)
                    else:
                        if wait["lang"] == "JP":
                            kk.sendText(msg.to,"No one is inviting")
                        else:
                            kk.sendText(msg.to,"Sorry, nobody absent")
                else:
                    if wait["lang"] == "JP":
                        kk.sendText(msg.to,"Can not be used outside the group")
                    else:
                        kk.sendText(msg.to,"Not for use less than group")
#--------------------------------------------------------
            elif msg.text in ["Emilia cancel","K3 cancel"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    G = kc.getGroup(msg.to)
                    if G.invitee is not None:
                        gInviMids = [contact.mid for contact in G.invitee]
                        kc.cancelGroupInvitation(msg.to, gInviMids)
                    else:
                        if wait["lang"] == "JP":
                            kc.sendText(msg.to,"No one is inviting")
                        else:
                            kc.sendText(msg.to,"Sorry, nobody absent")
                else:
                    if wait["lang"] == "JP":
                        kc.sendText(msg.to,"Can not be used outside the group")
                    else:
                        kc.sendText(msg.to,"Not for use less than group")
#--------------------------------------------------------
            elif msg.text in ["Raphi cancel","K4 cancel"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    X = ks.getGroup(msg.to)
                    if X.invitee is not None:
                        gInviMids = [contact.mid for contact in X.invitee]
                        ks.cancelGroupInvitation(msg.to, gInviMids)
                    else:
                        if wait["lang"] == "JP":
                            ks.sendText(msg.to,"No one is inviting")
                        else:
                            ks.sendText(msg.to,"Sorry, nobody absent")
                else:
                    if wait["lang"] == "JP":
                        ks.sendText(msg.to,"Can not be used outside the group")
                    else:
                        ks.sendText(msg.to,"Not for use less than group")
#--------------------------------------------------------
            elif msg.text in ["Gabriel cancel","K5 cancel"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    X = ka.getGroup(msg.to)
                    if X.invitee is not None:
                        gInviMids = [contact.mid for contact in X.invitee]
                        ka.cancelGroupInvitation(msg.to, gInviMids)
                    else:
                        if wait["lang"] == "JP":
                            ka.sendText(msg.to,"No one is inviting")
                        else:
                            ka.sendText(msg.to,"Sorry, nobody absent")
                else:
                    if wait["lang"] == "JP":
                        ka.sendText(msg.to,"Can not be used outside the group")
                    else:
                        ka.sendText(msg.to,"Not for use less than group")
#--------------------------------------------------------
            elif msg.text in ["Vigne cancel","K6 cancel"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    X = kb.getGroup(msg.to)
                    if X.invitee is not None:
                        gInviMids = [contact.mid for contact in X.invitee]
                        kb.cancelGroupInvitation(msg.to, gInviMids)
                    else:
                        if wait["lang"] == "JP":
                            kb.sendText(msg.to,"No one is inviting")
                        else:
                            kb.sendText(msg.to,"Sorry, nobody absent")
                else:
                    if wait["lang"] == "JP":
                        kb.sendText(msg.to,"Can not be used outside the group")
                    else:
                        kb.sendText(msg.to,"Not for use less than group")
#--------------------------------------------------------
            elif msg.text in ["Satania cancel","K7 cancel"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    X = ko.getGroup(msg.to)
                    if X.invitee is not None:
                        gInviMids = [contact.mid for contact in X.invitee]
                        ko.cancelGroupInvitation(msg.to, gInviMids)
                    else:
                        if wait["lang"] == "JP":
                            ko.sendText(msg.to,"No one is inviting")
                        else:
                            ko.sendText(msg.to,"Sorry, nobody absent")
                else:
                    if wait["lang"] == "JP":
                        ko.sendText(msg.to,"Can not be used outside the group")
                    else:
                        ko.sendText(msg.to,"Not for use less than group")
#-------------------------------------------------------- 
            elif msg.text in ["Sagiri cancel","K8 cancel"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    X = ke.getGroup(msg.to)
                    if X.invitee is not None:
                        gInviMids = [contact.mid for contact in X.invitee]
                        ke.cancelGroupInvitation(msg.to, gInviMids)
                    else:
                        if wait["lang"] == "JP":
                            ke.sendText(msg.to,"No one is inviting")
                        else:
                            ke.sendText(msg.to,"Sorry, nobody absent")
                else:
                    if wait["lang"] == "JP":
                        ke.sendText(msg.to,"Can not be used outside the group")
                    else:
                        ke.sendText(msg.to,"Not for use less than group")
#--------------------------------------------------------
            elif msg.text in ["Ange cancel","K9 cancel"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    X = ku.getGroup(msg.to)
                    if X.invitee is not None:
                        gInviMids = [contact.mid for contact in X.invitee]
                        ku.cancelGroupInvitation(msg.to, gInviMids)
                    else:
                        if wait["lang"] == "JP":
                            ku.sendText(msg.to,"No one is inviting")
                        else:
                            ku.sendText(msg.to,"Sorry, nobody absent")
                else:
                    if wait["lang"] == "JP":
                        ku.sendText(msg.to,"Can not be used outside the group")
                    else:
                        ku.sendText(msg.to,"Not for use less than group")
#--------------------------------------------------------
            elif msg.text in ["Mirai cancel","K10 cancel"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    X = kv.getGroup(msg.to)
                    if X.invitee is not None:
                        gInviMids = [contact.mid for contact in X.invitee]
                        kv.cancelGroupInvitation(msg.to, gInviMids)
                    else:
                        if wait["lang"] == "JP":
                            kv.sendText(msg.to,"No one is inviting")
                        else:
                            kv.sendText(msg.to,"Sorry, nobody absent")
                else:
                    if wait["lang"] == "JP":
                        kv.sendText(msg.to,"Can not be used outside the group")
                    else:
                        kv.sendText(msg.to,"Not for use less than group")
#--------------------------------------------------------
            elif msg.text in ["Sakura cancel","K11 cancel"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    X = kw.getGroup(msg.to)
                    if X.invitee is not None:
                        gInviMids = [contact.mid for contact in X.invitee]
                        kw.cancelGroupInvitation(msg.to, gInviMids)
                    else:
                        if wait["lang"] == "JP":
                            kw.sendText(msg.to,"No one is inviting")
                        else:
                            kw.sendText(msg.to,"Sorry, nobody absent")
                else:
                    if wait["lang"] == "JP":
                        kw.sendText(msg.to,"Can not be used outside the group")
                    else:
                        kw.sendText(msg.to,"Not for use less than group")
#--------------------------------------------------------
            elif msg.text in ["Mitsuki cancel","K12 cancel"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    X = kx.getGroup(msg.to)
                    if X.invitee is not None:
                        gInviMids = [contact.mid for contact in X.invitee]
                        kx.cancelGroupInvitation(msg.to, gInviMids)
                    else:
                        if wait["lang"] == "JP":
                            kx.sendText(msg.to,"No one is inviting")
                        else:
                            kx.sendText(msg.to,"Sorry, nobody absent")
                else:
                    if wait["lang"] == "JP":
                        kx.sendText(msg.to,"Can not be used outside the group")
                    else:
                        kx.sendText(msg.to,"Not for use less than group")
#======================================================# 
            elif msg.text in ["Open","open"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    X = cl.getGroup(msg.to)
                    X.preventJoinByTicket = False
                    cl.updateGroup(X)
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Invite by link open")
                    else:
                        cl.sendText(msg.to,"Already open")
                else:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Can not be used outside the group")
                    else:
                        cl.sendText(msg.to,"Not for use less than group")
#--------------------------------------------------------
            elif msg.text in ["Ram open","K1 open"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    X = cl.getGroup(msg.to)
                    X.preventJoinByTicket = False
                    ki.updateGroup(X)
                    if wait["lang"] == "JP":
                        ki.sendText(msg.to,"Done")
                    else:
                        ki.sendText(msg.to,"already open")
                else:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Can not be used outside the group")
                    else:
                        cl.sendText(msg.to,"Not for use less than group")
#--------------------------------------------------------
            elif msg.text in ["Rem open","K2 open"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    X = kk.getGroup(msg.to)
                    X.preventJoinByTicket = False
                    kk.updateGroup(X)
                    if wait["lang"] == "JP":
                        kk.sendText(msg.to,"Done")
                    else:
                        kk.sendText(msg.to,"already open")
                else:
                    if wait["lang"] == "JP":
                        kk.sendText(msg.to,"Can not be used outside the group")
                    else:
                        kk.sendText(msg.to,"Not for use less than group")
#--------------------------------------------------------
            elif msg.text in ["Emilia open","K3 open"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    X = kc.getGroup(msg.to)
                    X.preventJoinByTicket = False
                    kc.updateGroup(X)
                    if wait["lang"] == "JP":
                        kc.sendText(msg.to,"Done")
                    else:
                        kc.sendText(msg.to,"already open")
                else:
                    if wait["lang"] == "JP":
                        kc.sendText(msg.to,"Can not be used outside the group")
                    else:
                        kc.sendText(msg.to,"Not for use less than group")
#--------------------------------------------------------
            elif msg.text in ["Raphi open","K4 open"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    X = ks.getGroup(msg.to)
                    X.preventJoinByTicket = False
                    ks.updateGroup(X)
                    if wait["lang"] == "JP":
                        ks.sendText(msg.to,"Done")
                    else:
                        ks.sendText(msg.to,"Already open")
                else:
                    if wait["lang"] == "JP":
                        ks.sendText(msg.to,"Can not be used outside the group")
                    else:
                        ks.sendText(msg.to,"Not for use less than group")
#--------------------------------------------------------
            elif msg.text in ["Gabriel open","K5 open"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    X = ks.getGroup(msg.to)
                    X.preventJoinByTicket = False
                    ka.updateGroup(X)
                    if wait["lang"] == "JP":
                        ka.sendText(msg.to,"Done")
                    else:
                        ka.sendText(msg.to,"Already open")
                else:
                    if wait["lang"] == "JP":
                        ka.sendText(msg.to,"Can not be used outside the group")
                    else:
                        ka.sendText(msg.to,"Not for use less than group")
#--------------------------------------------------------
            elif msg.text in ["Vigne open","K6 open"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    X = kb.getGroup(msg.to)
                    X.preventJoinByTicket = False
                    kb.updateGroup(X)
                    if wait["lang"] == "JP":
                        kb.sendText(msg.to,"Done")
                    else:
                        kb.sendText(msg.to,"Already open")
                else:
                    if wait["lang"] == "JP":
                        kb.sendText(msg.to,"Can not be used outside the group")
                    else:
                        kb.sendText(msg.to,"Not for use less than group")
#--------------------------------------------------------
            elif msg.text in ["Satania open","K7 open"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    X = ko.getGroup(msg.to)
                    X.preventJoinByTicket = False
                    ko.updateGroup(X)
                    if wait["lang"] == "JP":
                        ko.sendText(msg.to,"Done")
                    else:
                        ko.sendText(msg.to,"Already open")
                else:
                    if wait["lang"] == "JP":
                        ko.sendText(msg.to,"Can not be used outside the group")
                    else:
                        ko.sendText(msg.to,"Not for use less than group")
#--------------------------------------------------------
            elif msg.text in ["Sagiri open","K8 open"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    X = ke.getGroup(msg.to)
                    X.preventJoinByTicket = False
                    ke.updateGroup(X)
                    if wait["lang"] == "JP":
                        ke.sendText(msg.to,"Done")
                    else:
                        ke.sendText(msg.to,"Already open")
                else:
                    if wait["lang"] == "JP":
                        ke.sendText(msg.to,"Can not be used outside the group")
                    else:
                        ke.sendText(msg.to,"Not for use less than group")
#--------------------------------------------------------
            elif msg.text in ["Erio open","K9 open"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    X = ku.getGroup(msg.to)
                    X.preventJoinByTicket = False
                    ku.updateGroup(X)
                    if wait["lang"] == "JP":
                        ku.sendText(msg.to,"Done")
                    else:
                        ku.sendText(msg.to,"Already open")
                else:
                    if wait["lang"] == "JP":
                        ku.sendText(msg.to,"Can not be used outside the group")
                    else:
                        ku.sendText(msg.to,"Not for use less than group")
#--------------------------------------------------------
            elif msg.text in ["Mirai open","K10 open"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    X = kv.getGroup(msg.to)
                    X.preventJoinByTicket = False
                    kv.updateGroup(X)
                    if wait["lang"] == "JP":
                        kv.sendText(msg.to,"Done")
                    else:
                        kv.sendText(msg.to,"Already open")
                else:
                    if wait["lang"] == "JP":
                        kv.sendText(msg.to,"Can not be used outside the group")
                    else:
                        kv.sendText(msg.to,"Not for use less than group")
#======================================================#
            elif msg.text in ["Close","close url"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    X = cl.getGroup(msg.to)
                    X.preventJoinByTicket = True
                    cl.updateGroup(X)
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Done。")
                    else:
                        cl.sendText(msg.to,"Already Close。")
                else:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Can not be used outside the group")
                    else:
                        cl.sendText(msg.to,"Not for use less than group")
#======================================================# 
            elif "jointicket " in msg.text.lower():
		rplace=msg.text.lower().replace("jointicket ")
		if rplace == "on":
			wait["atjointicket"]=True
		elif rplace == "off":
			wait["atjointicket"]=False
		cl.sendText(msg.to,"Auto Join Group by Ticket is %s" % str(wait["atjointicket"]))
            elif '/ti/g/' in msg.text.lower():
		link_re = re.compile('(?:line\:\/|line\.me\/R)\/ti\/g\/([a-zA-Z0-9_-]+)?')
		links = link_re.findall(msg.text)
		n_links=[]
		for l in links:
			if l not in n_links:
				n_links.append(l)
		for ticket_id in n_links:
			if wait["atjointicket"] == True:
				group=cl.findGroupByTicket(ticket_id)
				cl.acceptGroupInvitationByTicket(group.mid,ticket_id)
				cl.sendText(msg.to,"Sukses join ke grup %s" % str(group.name))
#======================================================# 
            elif msg.text == "Ginfo":
                if msg.toType == 2:
                    ginfo = cl.getGroup(msg.to)
                    try:
                        gCreator = ginfo.creator.displayName
                    except:
                        gCreator = "Error"
                    if wait["lang"] == "JP":
                        if ginfo.invitee is None:
                            sinvitee = "0"
                        else:
                            sinvitee = str(len(ginfo.invitee))
                        if ginfo.preventJoinByTicket == True:
                            u = "close"
                        else:
                            u = "open"
                        cl.sendText(msg.to,"[group name]\n" + str(ginfo.name) + "\n[gid]\n" + msg.to + "\n[group creator]\n" + gCreator + "\n[profile status]\nhttp://dl.profile.line.naver.jp/" + ginfo.pictureStatus + "\nmembers:" + str(len(ginfo.members)) + "members\npending:" + sinvitee + "people\nURL:" + u + "it is inside")
                    else:
                        cl.sendText(msg.to,"[group name]\n" + str(ginfo.name) + "\n[gid]\n" + msg.to + "\n[group creator]\n" + gCreator + "\n[profile status]\nhttp://dl.profile.line.naver.jp/" + ginfo.pictureStatus)
                else:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Can not be used outside the group")
                    else:
                        cl.sendText(msg.to,"Not for use less than group")
#==============================================================================
            if msg.contentType == 13:
                if wait["stealcontact"] == True:
                    if msg.from_ in admin:
                        _name = msg.contentMetadata["displayName"]
                        copy = msg.contentMetadata["mid"]
                        groups = cl.getGroup(msg.to)
                        pending = groups.invitee
                        targets = []
                        for s in groups.members:
                            if _name in s.displayName:
                                print "[Target] Stealed"
                                break                             
                            else:
                                targets.append(copy)
                        if targets == []:
                            pass
                        else:
                            for target in targets:
                                try:
                                    cl.findAndAddContactsByMid(target)
                                    contact = cl.getContact(target)
                                    y = contact.statusMessage
                                    cu = cl.channel.getCover(target)
                                    path = str(cu)
                                    image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                                    cl.sendText(msg.to,"Profile Picture " + contact.displayName)
                                    cl.sendImageWithURL(msg.to,image)
                                    cl.sendText(msg.to,"Cover " + contact.displayName)
                                    cl.sendImageWithURL(msg.to,path)
                                    wait["stealcontact"] = False
                                    break
                                except:
                                    pass
#======================================================# 
                elif wait["pc"] == True:
                    if msg.from_ in admin:
                        _name = msg.contentMetadata["displayName"]
                        pc = msg.contentMetadata["mid"]
                        groups = cl.getGroup(msg.to)
                        pending = groups.invitee
                        teks = wait["pm"]
                        targets = []
                        for s in groups.members:
                            if _name in s.displayName:
                                print "[Target] Personal Message"
                                break                             
                            else:
                                targets.append(pc)
                        if targets == []:
                            pass
                        else:
                            for target in targets:
                                try:
                                    cl.sendText(target,teks+"\n\n\nHm....")
                                    cl.sendText(msg.to,"Pesan telah dikirim ke " + _name)
                                    wait["pc"] = False
                                    break
                                except:
                                    pass
#======================================================# 
            elif msg.text in ["Group creator","Gcreator","gcreator"]:
                try:
                    ginfo = cl.getGroup(msg.to)
                    gCreator = ginfo.creator.mid
                    msg.contentType = 13
                    msg.contentMetadata = {"mid":gCreator}
                    cl.sendMessage(msg)
                    cl.sendText(msg.to,"👆Group Creator👆")
                except Exception as error:
                    print error
#======================================================# 
                 #------------Show contact dari mid-----------#
            elif "Check:" in msg.text:
                midd = msg.text.replace("Check:","")
                msg.contentType = 13
                msg.contentMetadata = {"mid":midd}
                cl.sendMessage(msg)
#======================================================#
            elif "Mid? " in msg.text:
                   key = eval(msg.contentMetadata["MENTION"]) 
                   key1 = key["MENTIONEES"][0]["M"] 
                   mi = cl.getContact(key1) 
                   cl.sendText(msg.to,"Mid\n" + key1)
            elif "Mid @" in msg.text:
                _name = msg.text.replace("Mid @","")
                _nametarget = _name.rstrip(' ')
                gs = cl.getGroup(msg.to)
                for g in gs.members:
                    if _nametarget == g.displayName:
                        cl.sendText(msg.to, g.mid)
                    else:
                        pass
#===============================================================================
            elif "Info " in msg.text:
                   key = eval(msg.contentMetadata["MENTION"]) 
                   key1 = key["MENTIONEES"][0]["M"] 
                   mi = cl.getContact(key1) 
                   cl.sendText(msg.to,"[Name]\n" + mi.displayName + "\n[Mid]\n" + key1 + "\n[Bio]\n" + mi.statusMessage)
                   
#======================================================#
            elif "My mid" == msg.text:
                cl.sendText(msg.to, msg.from_)
#--------------------------------------------------------------#
            elif "All mid" == msg.text:
                cl.sendText(msg.to,mid)
                ki.sendText(msg.to,Amid)
                kk.sendText(msg.to,Bmid)
                kc.sendText(msg.to,Cmid)
                ks.sendText(msg.to,Dmid)
                ka.sendText(msg.to,Emid)
                kb.sendText(msg.to,Fmid)
                ko.sendText(msg.to,Gmid)
                ke.sendText(msg.to,Hmid)
                kv.sendText(msg.to,Jmid)
                kw.sendText(msg.to,Kmid)
                kx.sendText(msg.to,Kmid)
#--------------------------------------------------------------#
            elif "Mid" == msg.text:
                cl.sendText(msg.to,mid)
            elif "Ram mid" == msg.text:
                ki.sendText(msg.to,Amid)
            elif "Rem mid" == msg.text:
                kk.sendText(msg.to,Bmid)
            elif "Emilia mid" == msg.text:
                kc.sendText(msg.to,Cmid)
            elif "Raphi mid" == msg.text:
                ks.sendText(msg.to,Dmid)
            elif "Gabriel mid" == msg.text:
                ka.sendText(msg.to,Emid)
            elif "Vigne mid" == msg.text:
                kb.sendText(msg.to,Fmid)
            elif "Satania mid" == msg.text:
            	ko.sendText(msg.to,Gmid)
            elif "Sagiri mid" == msg.text:
            	ke.sendText(msg.to,Hmid)
            elif "Erio mid" == msg.text:
            	ku.sendText(msg.to,Imid)
            elif "Mirai mid" == msg.text:
            	ku.sendText(msg.to,Jmid)
            elif "Sakura mid" == msg.text:
            	kw.sendText(msg.to,Kmid)
            elif "Mitsuki mid" == msg.text:
            	kx.sendText(msg.to,Lmid)
#======================================================#
   #         elif msg.text in ["Wkwkwk","Wkwk","Wk","wkwkwk","wkwk"]:
    #            msg.contentType = 7
     #           msg.text = None
        #        msg.contentMetadata = {
                               #      "STKID": "100",
                                 #    "STKPKGID": "1",
                          #           "STKVER": "100" }
#--------------------------------------------------------------#
            #---------------------------------------------------------
            elif "Rename:" in msg.text:
              if msg.from_ in Creator:
                string = msg.text.replace("Rename:","")
                if len(string.decode('utf-8')) <= 60000000:
                    profile = cl.getProfile()
                    profile.displayName = string
                    cl.updateProfile(profile)
                    cl.sendText(msg.to,"􀜁􀇔􏿿Update Names👉" + string + "👈")
#--------------------------------------------------------
            elif "Ram rename:" in msg.text:
              if msg.from_ in Creator:
                string = msg.text.replace("Ram rename:","")
                if len(string.decode('utf-8')) <= 60000000:
                    profile = ki.getProfile()
                    profile.displayName = string
                    ki.updateProfile(profile)
                    ki.sendText(msg.to,"􀜁􀇔􏿿Update Names👉" + string + "👈")
#--------------------------------------------------------
            elif "Rem rename:" in msg.text:
              if msg.from_ in Creator:
                string = msg.text.replace("Rem rename:","")
                if len(string.decode('utf-8')) <= 60000000:
                    profile = kk.getProfile()
                    profile.displayName = string
                    kk.updateProfile(profile)
                    kk.sendText(msg.to,"􀜁􀇔􏿿Update Names👉" + string + "👈")
#--------------------------------------------------------
            elif "Emilia rename:" in msg.text:
              if msg.from_ in Creator:
                string = msg.text.replace("Emilia rename:","")
                if len(string.decode('utf-8')) <= 60000000:
                    profile = kc.getProfile()
                    profile.displayName = string
                    kc.updateProfile(profile)
                    kc.sendText(msg.to,"􀜁􀇔􏿿Update Names👉" + string + "👈")
#--------------------------------------------------------
            elif "Raphi rename:" in msg.text:
              if msg.from_ in Creator:
                string = msg.text.replace("Raphi rename:","")
                if len(string.decode('utf-8')) <= 60000000:
                    profile = ks.getProfile()
                    profile.displayName = string
                    ks.updateProfile(profile)
                    ks.sendText(msg.to,"􀜁􀇔􏿿Update Names👉" + string + "👈")
#--------------------------------------------------------
            elif "Gabriel rename:" in msg.text:
              if msg.from_ in Creator:
                string = msg.text.replace("Gabriel rename:","")
                if len(string.decode('utf-8')) <= 60000000:
                    profile = ka.getProfile()
                    profile.displayName = string
                    ka.updateProfile(profile)
                    ka.sendText(msg.to,"􀜁􀇔􏿿Update Names👉" + string + "👈")
#--------------------------------------------------------
            elif "Vigne rename:" in msg.text:
              if msg.from_ in Creator:
                string = msg.text.replace("Vigne rename:","")
                if len(string.decode('utf-8')) <= 60000000:
                    profile = kb.getProfile()
                    profile.displayName = string
                    kb.updateProfile(profile)
                    kb.sendText(msg.to,"􀜁􀇔􏿿Update Names👉" + string + "👈")
#--------------------------------------------------------
            elif "Satania rename:" in msg.text:
              if msg.from_ in Creator:
                string = msg.text.replace("Satania rename:","")
                if len(string.decode('utf-8')) <= 60000000:
                    profile = ko.getProfile()
                    profile.displayName = string
                    ko.updateProfile(profile)
                    ko.sendText(msg.to,"􀜁􀇔􏿿Update Names👉" + string + "👈")
#--------------------------------------------------------
            elif "Sagiri rename:" in msg.text:
              if msg.from_ in Creator:
                string = msg.text.replace("Sagiri rename:","")
                if len(string.decode('utf-8')) <= 60000000:
                    profile = ke.getProfile()
                    profile.displayName = string
                    ke.updateProfile(profile)
                    ke.sendText(msg.to,"􀜁􀇔􏿿Update Names👉" + string + "👈")
#--------------------------------------------------------
            elif "Erio rename:" in msg.text:
              if msg.from_ in Creator:
                string = msg.text.replace("Erio rename:","")
                if len(string.decode('utf-8')) <= 60000000:
                    profile = ku.getProfile()
                    profile.displayName = string
                    ku.updateProfile(profile)
                    ku.sendText(msg.to,"􀜁􀇔􏿿Update Names👉" + string + "👈")
#--------------------------------------------------------
            elif "Mirai rename:" in msg.text:
              if msg.from_ in Creator:
                string = msg.text.replace("Mirai rename:","")
                if len(string.decode('utf-8')) <= 60000000:
                    profile = kv.getProfile()
                    profile.displayName = string
                    kv.updateProfile(profile)
                    kv.sendText(msg.to,"􀜁􀇔􏿿Update Names👉" + string + "👈")
#--------------------------------------------------------
            elif "Sakura rename:" in msg.text:
              if msg.from_ in Creator:
                string = msg.text.replace("Sakura rename:","")
                if len(string.decode('utf-8')) <= 60000000:
                    profile = kw.getProfile()
                    profile.displayName = string
                    kw.updateProfile(profile)
                    kw.sendText(msg.to,"􀜁􀇔􏿿Update Names👉" + string + "👈")
#--------------------------------------------------------
            elif "Mitsuki rename:" in msg.text:
              if msg.from_ in Creator:
                string = msg.text.replace("Mitsuki rename:","")
                if len(string.decode('utf-8')) <= 60000000:
                    profile = kx.getProfile()
                    profile.displayName = string
                    kx.updateProfile(profile)
                    kx.sendText(msg.to,"􀜁􀇔􏿿Update Names👉" + string + "👈")
#======================================================
            elif "Change bio:" in msg.text:
              if msg.from_ in admin:
                string = msg.text.replace("Change bio:","")
                if len(string.decode('utf-8')) <= 60000000000:
                    profile = cl.getProfile()
                    profile.statusMessage = string
                    cl.updateProfile(profile)
                    cl.sendText(msg.to,"􀜁􀇔􏿿Update Bio👉" + string + "👈")    
#--------------------------------------------------------
            elif "Ram change bio" in msg.text:
              if msg.from_ in admin:
                string = msg.text.replace("Ram change bio:","")
                if len(string.decode('utf-8')) <= 60000000000:
                    profile = ki.getProfile()
                    profile.statusMessage = string
                    ki.updateProfile(profile)
                    ki.sendText(msg.to,"􀜁􀇔􏿿Update Bio👉" + string + "👈")    
#--------------------------------------------------------
            elif "Rem change bio:" in msg.text:
              if msg.from_ in admin:
                string = msg.text.replace("Rem change bio:","")
                if len(string.decode('utf-8')) <= 60000000000:
                    profile = kk.getProfile()
                    profile.statusMessage = string
                    kk.updateProfile(profile)
                    kk.sendText(msg.to,"􀜁􀇔􏿿Update Bio👉" + string + "👈")    
#--------------------------------------------------------
            elif "Emilia change bio:" in msg.text:
              if msg.from_ in admin:
                string = msg.text.replace("Emilia change bio:","")
                if len(string.decode('utf-8')) <= 60000000000:
                    profile = kc.getProfile()
                    profile.statusMessage = string
                    kc.updateProfile(profile)
                    kc.sendText(msg.to,"􀜁􀇔􏿿Update Bio👉" + string + "👈")    
#--------------------------------------------------------
            elif "Raphi change bio:" in msg.text:
              if msg.from_ in admin:
                string = msg.text.replace("Raphi change bio:","")
                if len(string.decode('utf-8')) <= 60000000000:
                    profile = ks.getProfile()
                    profile.statusMessage = string
                    ks.updateProfile(profile)
                    ks.sendText(msg.to,"􀜁􀇔􏿿Update Bio👉" + string + "👈")    
#--------------------------------------------------------
            elif "Gabriel change bio:" in msg.text:
              if msg.from_ in admin:
                string = msg.text.replace("Gabriel change bio:","")
                if len(string.decode('utf-8')) <= 60000000000:
                    profile = ka.getProfile()
                    profile.statusMessage = string
                    ka.updateProfile(profile)
                    ka.sendText(msg.to,"􀜁􀇔􏿿Update Bio👉" + string + "👈")    
#--------------------------------------------------------
            elif "Vigne change bio:" in msg.text:
              if msg.from_ in admin:
                string = msg.text.replace("Vigne change bio:","")
                if len(string.decode('utf-8')) <= 60000000000:
                    profile = kb.getProfile()
                    profile.statusMessage = string
                    kb.updateProfile(profile)
                    kb.sendText(msg.to,"􀜁􀇔􏿿Update Bio👉" + string + "👈")    
#--------------------------------------------------------
            elif "Satania change bio:" in msg.text:
              if msg.from_ in admin:
                string = msg.text.replace("Satania change bio:","")
                if len(string.decode('utf-8')) <= 60000000000:
                    profile = ko.getProfile()
                    profile.statusMessage = string
                    ko.updateProfile(profile)
                    ko.sendText(msg.to,"􀜁􀇔􏿿Update Bio👉" + string + "👈")    
#--------------------------------------------------------
            elif "Sagiri change bio:" in msg.text:
              if msg.from_ in admin:
                string = msg.text.replace("Sagiri change bio:","")
                if len(string.decode('utf-8')) <= 60000000000:
                    profile = ke.getProfile()
                    profile.statusMessage = string
                    ke.updateProfile(profile)
                    ke.sendText(msg.to,"􀜁􀇔􏿿Update Bio👉" + string + "👈")    
#--------------------------------------------------------
            elif "Erio change bio:" in msg.text:
              if msg.from_ in admin:
                string = msg.text.replace("Erio change bio:","")
                if len(string.decode('utf-8')) <= 60000000000:
                    profile = ku.getProfile()
                    profile.statusMessage = string
                    ku.updateProfile(profile)
                    ku.sendText(msg.to,"??􀇔􏿿Update Bio??" + string + "👈")    
#--------------------------------------------------------
            elif "Mirai change bio:" in msg.text:
              if msg.from_ in admin:
                string = msg.text.replace("Mirai change bio:","")
                if len(string.decode('utf-8')) <= 60000000000:
                    profile = kv.getProfile()
                    profile.statusMessage = string
                    kv.updateProfile(profile)
                    kv.sendText(msg.to,"􀜁􀇔􏿿Update Bio👉" + string + "👈")    
#--------------------------------------------------------
            elif "Sakura change bio:" in msg.text:
              if msg.from_ in admin:
                string = msg.text.replace("Sakura change bio:","")
                if len(string.decode('utf-8')) <= 60000000000:
                    profile = kw.getProfile()
                    profile.statusMessage = string
                    kw.updateProfile(profile)
                    kw.sendText(msg.to,"􀜁􀇔􏿿Update Bio👉" + string + "👈")    
#--------------------------------------------------------
            elif "Mitsuki change bio:" in msg.text:
              if msg.from_ in admin:
                string = msg.text.replace("Mitsuki change bio:","")
                if len(string.decode('utf-8')) <= 60000000000:
                    profile = kx.getProfile()
                    profile.statusMessage = string
                    kx.updateProfile(profile)
                    kx.sendText(msg.to,"􀜁􀇔􏿿Update Bio👉" + string + "👈")
#======================================================#
            elif msg.text in ["Cancel on","Guest on"]:
              if msg.from_ in admin:
                if wait["Protectguest"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Already On。")
                else:
                    wait["Protectguest"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Block Invite On")
#--------------------------------------------------------
            elif msg.text in ["Cancel off","guest off"]:
              if msg.from_ in admin:
                if wait["Protectguest"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Already Off。")
                else:
                    wait["Protectguest"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Block Invite Off。")
#======================================================# 
            elif msg.text in ["Protect on","Kick on"]:
              if msg.from_ in admin:
                if wait["ProtectGroup"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Already on。")
                else:
                    wait["ProtectGroup"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"はい\nDone。") 
#--------------------------------------------------------
            elif msg.text in ["Protect off","Kick off"]:
              if msg.from_ in admin:
                if wait["ProtectGroup"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Already off。")
                else:
                    wait["Protectcancel"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"はい\nDone。")
#======================================================# 
            elif msg.text in ["Protect cancel on","Cancl on"]:
              if msg.from_ in admin:
                if wait["Protectcancel"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Already on。")
                else:
                    wait["Protectcancel"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Jangan cancel pend tar kecyduck")
#--------------------------------------------------------
            elif msg.text in ["Protect cancel off","Cancl off"]:
              if msg.from_ in admin:
                if wait["Protectcancel"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Already off。")
                else:
                    wait["Protectcancel"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"はい\nDone。")
#======================================================# 
            elif msg.text in ["QR on","qr on"]:
              if msg.from_ in admin:
                if wait["ProtectQR"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Already On。")
                else:
                    wait["ProtectQR"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protect QR On。")
#--------------------------------------------------------
            elif msg.text in ["QR off","qr off"]:
              if msg.from_ in admin:
                if wait["ProtectQR"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Already Off。")
                else:
                    wait["ProtectQR"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Protect QR Off")
#======================================================# 
            elif msg.text in ["Contact On","Contact on","contact on"]:
              if msg.from_ in admin:
                if wait["contact"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Already On。")
                else:
                    wait["contact"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"はい\nDone。")
#--------------------------------------------------------
            elif msg.text in ["Contact Off","Contact off","contact off"]:
              if msg.from_ in admin:
                if wait["contact"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Already Off。")
                else:
                    wait["contact"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"はい\nDone。")
#======================================================# 
            elif msg.text in ["Join on","Auto join:on"]:
              if msg.from_ in admin:
                if wait["autoJoin"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Already On。")
                else:
                    wait["autoJoin"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"はい\nDone。")
#--------------------------------------------------------
            elif msg.text in ["Join off","Auto join:off"]:
              if msg.from_ in admin:
                if wait["autoJoin"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Already Off。")
                else:
                    wait["autoJoin"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"はい\nDone。")
#======================================================# 
            elif msg.text in ["Gcancel:"]:
                try:
                    strnum = msg.text.replace("Gcancel:","")
                    if strnum == "off":
                        wait["autoCancel"]["on"] = False
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,"Invitation refused turned off\nTo turn on please specify the number of people and send")
                        else:
                            cl.sendText(msg.to,"å…³äº†é‚€è¯·æ‹’ç»�ã€‚è¦�æ—¶å¼€è¯·æŒ‡å®šäººæ•°å�‘é€�")
                    else:
                        num =  int(strnum)
                        wait["autoCancel"]["on"] = True
                        if wait["lang"] == "JP":
                            cl.sendText(msg.to,strnum + "The group of people and below decided to automatically refuse invitation")
                        else:
                            cl.sendText(msg.to,strnum + "ä½¿äººä»¥ä¸‹çš„å°�ç»„ç”¨è‡ªåŠ¨é‚€è¯·æ‹’ç»�")
                except:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Value is wrong")
                    else:
                        cl.sendText(msg.to,"Bizarre ratings")
#======================================================# 
            elif msg.text in ["Leave on","Auto leave:on"]:
              if msg.from_ in admin: 
                if wait["leaveRoom"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Already On。")
                else:
                    wait["leaveRoom"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"はい\nDone。")
#--------------------------------------------------------
            elif msg.text in ["Auto leave off","Leave off"]:
              if msg.from_ in admin:
                if wait["leaveRoom"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Already Off。")
                else:
                    wait["leaveRoom"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"はい\nDone。")
#======================================================# 
            elif msg.text in ["Share on","Siri:on"]:
                if wait["timeline"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Already On。")
                else:
                    wait["timeline"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"はい\nDone。")
#--------------------------------------------------------
            elif msg.text in ["Share off","Siri:off"]:
                if wait["timeline"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Already Off。")
                else:
                    wait["timeline"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"はい\nDone。")
#======================================================# 
            elif msg.text in ["Notifed on","notifed on"]:
              if msg.from_ in admin:
                if wait["Notifed"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Already On。")
                else:
                    wait["Notifed"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"はい\nDone。")
#--------------------------------------------------------
            elif msg.text in ["Notifed off","notifed off"]:
              if msg.from_ in admin:
                if wait["Notifed"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Already Off。")
                else:
                    wait["Notifed"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"はい\nDone。")
#======================================================# 
            elif msg.text in ["Like on","Auto like on"]:
              if msg.from_ in admin: 
                if wait["likeOn"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Already On。")
                else:
                    wait["likeOn"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"はい\nDone。")
#--------------------------------------------------------
            elif msg.text in ["Auto like off","Like off"]:
              if msg.from_ in admin:
                if wait["likeOn"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Already Off。")
                else:
                    wait["likeOn"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"はい\nDone。")
#======================================================# 
            elif msg.text in ["Tag on","Respon tag on"]:
              if msg.from_ in admin:
                if wait["ResponTag"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Already On。")
                else:
                    wait["ResponTag"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"はい\nDone。")
#--------------------------------------------------------
            elif msg.text in ["Tag off","Respon tag off"]:
              if msg.from_ in admin:
                if wait["ResponTag"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Already Off。")
                else:
                    wait["ResponTag"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"はい\nDone。")
#======================================================# 
            elif msg.text in ["Sett"]:
              if msg.from_ in admin:
                md = ""
                if wait["ProtectGroup"] == True: md+="≫ ProtectGroup : on\n"
                else: md+="≫ Protect Group : off\n"
                if wait["ProtectQR"] == True: md+="≫ Protect QR : on\n"
                else: md+="≫ Protect QR : off\n"
                if wait["Protectcancel"] == True: md+="≫ Protect cancel : on\n"
                else: md+="≫ Protect Cancel : off\n"
                if wait["Protectguest"] == True: md+="≫ Block Invite : on\n"
                else: md+="≫ Block Invite : off\n"
                if wait["Notifed"] == True: md+="≫ Notifed    : on\n"
                else: md+="≫ Notifed    : off\n"
                if wait["contact"] == True: md+="≫ Contact    : on\n"
                else: md+="≫ Contact    : off\n"
                if wait["autoJoin"] == True: md+="≫ Auto Join : on\n"
                else: md +="≫ Auto Join : off\n"
                if wait["autoCancel"]["on"] == True:md+="≫ Group Cancel :" + str(wait["autoCancel"]["members"]) + "\n"
                else: md+="≫ Group Cancel : off\n"
                if wait["leaveRoom"] == True: md+="≫ Auto Leave    : on\n"
                else: md+="≫ Auto Leave : off\n"
                if wait["timeline"] == True: md+="≫ Share   : on\n"
                else:md+="≫ Share   : off\n"
                if wait["autoAdd"] == True: md+="≫ Auto Add : on\n"
                else:md+="≫ Auto Add : off\n"
                if wait["likeOn"] == True: md+="≫ Auto Like : on \n"
                else:md+="≫ Auto Like : off \n" 
                if wait["commentOn"] == True: md+="≫ Comment : on \n"
                else:md+="≫ Comment : off \n" 
                if wait["ResponTag"] == True: md+="≫ Auto Respon : on \n"
                else:md+="≫ Auto Respon : off \n" 
                cl.sendText(msg.to,md)
#======================================================# 
            elif msg.text in ["My groups","Emilia gc","Group"]:
                if msg.from_ in admin:
                 gid = cl.getGroupIdsJoined()
                 h = ""
                 for i in gid:
                  h += "[☆]。 %s  \n" % (cl.getGroup(i).name + "[" + str(len (cl.getGroup(i).members)) + "]")
                 cl.sendText(msg.to, "[=====☆My Groups☆=====]\n"+ h +"☆ Jumlah : " +str(len(gid)))
            elif msg.text in ["Ram groups"]:
                if msg.from_ in admin:
                 gid = ki.getGroupIdsJoined()
                 h = ""
                 for i in gid:
                  h += "▶。 %s  \n" % (ki.getGroup(i).name + " | : " + str(len (ki.getGroup(i).members)))
                 ki.sendText(msg.to, "◀My Groups▶\n"+ h +"▶Jumlah : " +str(len(gid)))
            elif msg.text in ["Gid","Group id"]:
                gid = cl.getGroupIdsJoined()
                h = ""
                for i in gid:
                    h += "[%s]:[%s]\n" % (cl.getGroup(i).name,i)
                cl.sendText(msg.to,h)
#======================================================# 
            elif msg.text in ["Cancelall"]:
              if msg.from_ in admin:
                gid = cl.getGroupIdsInvited()
                for i in gid:
                    cl.rejectGroupInvitation(i)
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,"All invitations have been refused")
                else:
                    cl.sendText(msg.to,"æ‹’ç»�äº†å…¨éƒ¨çš„é‚€è¯·ã€‚")
#======================================================# 
            elif msg.text in ["Add on","Auto add:on","è‡ªå‹•è¿½åŠ ï¼šé–‹"]:
              if msg.from_ in admin:
                if wait["autoAdd"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"already on")
                    else:
                        cl.sendText(msg.to,"done")
                else:
                    wait["autoAdd"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"done")
            elif msg.text in ["Add off","Auto add:off"]:
              if msg.from_ in admin:
                if wait["autoAdd"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"already off")
                    else:
                        cl.sendText(msg.to,"done")
                else:
                    wait["autoAdd"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"done")
                    else:
                        cl.sendText(msg.to,"è¦�äº†å…³æ–­ã€‚")
#======================================================# 
            elif "Message change: " in msg.text:
              if msg.from_ in admin:
                wait["message"] = msg.text.replace("Message change: ","")
                cl.sendText(msg.to,"message changed")
            elif "Add message:" in msg.text:
              if msg.from_ in admin:
                wait["message"] = msg.text.replace("Add message:","")
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,"message changed")
                else:
                    cl.sendText(msg.to,"doneã€‚")
            elif msg.text in ["Message"]:
              if msg.from_ in admin:
                if wait["lang"] == "JP":
                    cl.sendText(msg.to,"👇Message Add👇\n\n" + wait["message"])
                else:
                    cl.sendText(msg.to,"The automatic appending information is set as followsã€‚\n\n" + wait["message"])
#======================================================# 
            elif "Add comment:" in msg.text:
              if msg.from_ in admin:
                c = msg.text.replace("Add comment:","")
                if c in [""," ","\n",None]:
                    cl.sendText(msg.to,"String that can not be changed")
                else:
                    wait["comment"] = c
                    cl.sendText(msg.to,"changed\n\n" + c)
            elif msg.text in ["Comment on"]:
              if msg.from_ in admin:
                if wait["commentOn"] == True:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Already On。")
                else:
                    wait["commentOn"] = True
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Done。")
            elif msg.text in ["Comment off"]:
              if msg.from_ in admin:
                if wait["commentOn"] == False:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Already Off-_-")
                else:
                    wait["commentOn"] = False
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Done。")
            elif msg.text in ["Comment"]:
              if msg.from_ in admin:
                cl.sendText(msg.to,"👇Auto Comment👇\n\n" + str(wait["comment"]))     
#--------------------------------------------------------------#
            elif msg.text in ["Url"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    x = cl.getGroup(msg.to)
                    if x.preventJoinByTicket == True:
                        x.preventJoinByTicket = False
                        cl.updateGroup(x)
                    gurl = cl.reissueGroupTicket(msg.to)
                    cl.sendText(msg.to,"line://ti/g/" + gurl)
                else:
                    if wait["lang"] == "JP":
                        cl.sendText(msg.to,"Can't be used outside the group")
                    else:
                        cl.sendText(msg.to,"Not for use less than group")
#--------------------------------------------------------------#
            elif msg.text in ["Comment bl "]:
              if msg.from_ in admin:
                wait["wblack"] = True
                cl.sendText(msg.to,"add to comment bl")
            elif msg.text in ["Comment wl "]:
                wait["dblack"] = True
                cl.sendText(msg.to,"wl to comment bl")
            elif msg.text in ["Comment bl confirm"]:
                if wait["commentBlack"] == {}:
                    cl.sendText(msg.to,"confirmed")
                else:
                    cl.sendText(msg.to,"Blacklist")
                    mc = ""
                    for mi_d in wait["commentBlack"]:
                        mc += "" +cl.getContact(mi_d).displayName + "\n"
                    cl.sendText(msg.to,mc) 
#======================================================# 
            elif "Setlastpoint" in msg.text:
                subprocess.Popen("echo '' > dataSeen/"+msg.to+".txt", shell=True, stdout=subprocess.PIPE)
                cl.sendText(msg.to, "Set the lastseens' point(｀・ω・´)\n\n" + datetime.now().strftime('%H:%M:%S'))
                print "Setlastpoint"

            elif "Viewlastseen" in msg.text:
	        lurkGroup = ""
	        dataResult, timeSeen, contacts, userList, timelist, recheckData = [], [], [], [], [], []
                with open('dataSeen/'+msg.to+'.txt','r') as rr:
                    contactArr = rr.readlines()
                    for v in xrange(len(contactArr) -1,0,-1):
                        num = re.sub(r'\n', "", contactArr[v])
                        contacts.append(num)
                        pass
                    contacts = list(set(contacts))
                    for z in range(len(contacts)):
                        arg = contacts[z].split('|')
                        userList.append(arg[0])
                        timelist.append(arg[1])
                    uL = list(set(userList))
                    for ll in range(len(uL)):
                        try:
                            getIndexUser = userList.index(uL[ll])
                            timeSeen.append(time.strftime("%d日 %H:%M:%S", time.localtime(int(timelist[getIndexUser]) / 1000)))
                            recheckData.append(userList[getIndexUser])
                        except IndexError:
                            conName.append('nones')
                            pass
                    contactId = cl.getContacts(recheckData)
                    for v in range(len(recheckData)):
                        dataResult.append(contactId[v].displayName + ' ('+timeSeen[v]+')')
                        pass
                    if len(dataResult) > 0:
                        grp = '\n• '.join(str(f) for f in dataResult)
                        total = '\nThese %iuesrs have seen at the lastseen\npoint(｀・ω・´)\n\n%s' % (len(dataResult), datetime.now().strftime('%H:%M:%S') )
                        cl.sendText(msg.to, "• %s %s" % (grp, total))
                    else:
                        cl.sendText(msg.to, "KAGA ADA SIDERR!!!\nTOLOL!!!!!\nATO LU GA KETIK SETLASTPOINT DULU GOBLOK!!!!!")
                    print "Viewlastseen"
#======================================================# 
            elif msg.text in ["Cek"]:
                cl.sendText(msg.to, "Set the lastseens' point(｀・ω・´)\n\n" + datetime.now().strftime('%H:%M:%S'))
                try:
                  del wait2['readPoint'][msg.to]
                  del wait2['readMember'][msg.to]
                except:
	            pass
                now2 = datetime.now()
                wait2['readPoint'][msg.to] = msg.id
                wait2['readMember'][msg.to] = ""
                wait2['setTime'][msg.to] = datetime.now().strftime('%H:%M:%S')
                wait2['ROM'][msg.to] = {}
                print wait2

            elif msg.text in ["Sider"]:
		  if msg.to in wait2['readPoint']:
	            if wait2["ROM"][msg.to].items() == []:
	              chiya = ""
	            else:
	              chiya = ""
	              for rom in wait2["ROM"][msg.to].items():
	                print rom
	                chiya += rom[1] + "\n"

	            cl.sendText(msg.to, " %s\n\n◀◀◀◀⚫▶▶▶▶\n\n%s\n\nThese uesrs have seen at the lastseen\npoint(｀・ω・´)\n%s"  % (wait2['readMember'][msg.to],chiya,setTime[msg.to]))
	          else:
	            cl.sendText(msg.to, "Sider ga bisa di read cek setpoint dulu bego tinggal ketik\nSetlastpoint\nkalo mau liat sider ketik\nViewlastseen")
#======================================================# 
         #----------------Fungsi Join Group Start-----------------------#
            elif msg.text in ["Kicker","Come here"]:
              if msg.from_ in admin:
                        G = cl.getGroup(msg.to)
                        ginfo = cl.getGroup(msg.to)
                        G.preventJoinByTicket = False
                        cl.updateGroup(G)
                        invsend = 0
                        Ticket = cl.reissueGroupTicket(msg.to)
                        ki.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.2)
                        kk.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.2)
                        kc.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.2)
                        ks.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.2)
                        ka.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.2)
                        kb.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.2)
                        ko.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.2)
                        ke.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.2)
                        ku.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.2)
                        kv.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.2)
                        kw.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.2)
                        kx.acceptGroupInvitationByTicket(msg.to,Ticket)
                        time.sleep(0.2)
                        G = ki.getGroup(msg.to)
                        G.preventJoinByTicket = True
                        ki.updateGroup(G)
                        print "🔸Kicker Complete"
                        G.preventJoinByTicket(G)
                        ki.updateGroup(G)

            elif msg.text in ["Kicker1","Ram join"]:
              if msg.from_ in admin:
                  X = cl.getGroup(msg.to)
                  X.preventJoinByTicket = False
                  cl.updateGroup(X)
                  invsend = 0
                  Ti = cl.reissueGroupTicket(msg.to)
                  ki.acceptGroupInvitationByTicket(msg.to,Ti)
                  G = ki.getGroup(msg.to)
                  G.preventJoinByTicket = True
                  ki.updateGroup(G)
                  Ticket = ki.reissueGroupTicket(msg.to)

            elif msg.text in ["Kicker2","Rem join"]:
              if msg.from_ in admin:
                  X = cl.getGroup(msg.to)
                  X.preventJoinByTicket = False
                  cl.updateGroup(X)
                  invsend = 0
                  Ti = cl.reissueGroupTicket(msg.to)
                  kk.acceptGroupInvitationByTicket(msg.to,Ti)
                  G = kk.getGroup(msg.to)
                  G.preventJoinByTicket = True
                  kk.updateGroup(G)
                  Ticket = kk.reissueGroupTicket(msg.to)

            elif msg.text in ["Kicker3","Emilia join"]:
              if msg.from_ in admin:
                  X =cl.getGroup(msg.to)
                  X.preventJoinByYicket = False
                  cl.updateGroup(X)
                  invsend = 0
                  Ti = cl.reissueGroupTicket(msg.to)
                  kc.acceptGroupInvitationByTicket(msg.to,Ti)
                  G = kc.getGroup(msg.to)
                  G.preventJoinByTicket = True
                  kc.updateGroup(G)
                  Ticket = kc.reissueGroupTicket(msg.to)
                  
            elif msg.text in ["Kicker4","Raphi join"]:
              if msg.from_ in admin:
                  X =cl.getGroup(msg.to)
                  X.preventJoinByYicket = False
                  cl.updateGroup(X)
                  invsend = 0
                  Ti = cl.reissueGroupTicket(msg.to)
                  ks.acceptGroupInvitationByTicket(msg.to,Ti)
                  G = ks.getGroup(msg.to)
                  G.preventJoinByTicket = True
                  ks.updateGroup(G)
                  Ticket = ks.reissueGroupTicket(msg.to)
     
            elif msg.text in ["Kicker5","Gabriel join"]:
              if msg.from_ in admin:
                  X =cl.getGroup(msg.to)
                  X.preventJoinByYicket = False
                  cl.updateGroup(X)
                  invsend = 0
                  Ti = cl.reissueGroupTicket(msg.to)
                  ka.acceptGroupInvitationByTicket(msg.to,Ti)
                  G = ka.getGroup(msg.to)
                  G.preventJoinByTicket = True
                  ka.updateGroup(G)
                  Ticket = ka.reissueGroupTicket(msg.to)
                  
            elif msg.text in ["Kicker6","Vigne join"]:
              if msg.from_ in admin:
                  X =cl.getGroup(msg.to)
                  X.preventJoinByYicket = False
                  cl.updateGroup(X)
                  invsend = 0
                  Ti = cl.reissueGroupTicket(msg.to)
                  kb.acceptGroupInvitationByTicket(msg.to,Ti)
                  G = cl.getGroup(msg.to)
                  G.preventJoinByTicket = True
                  kb.updateGroup(G)
                  Ticket = kb.reissueGroupTicket(msg.to)
                 
            elif msg.text in ["Kicker7","Satania join"]:
              if msg.from_ in admin:
                  X =cl.getGroup(msg.to)
                  X.preventJoinByYicket = False
                  cl.updateGroup(X)
                  invsend = 0
                  Ti = cl.reissueGroupTicket(msg.to)
                  ko.acceptGroupInvitationByTicket(msg.to,Ti)
                  G = ko.getGroup(msg.to)
                  G.preventJoinByTicket = True
                  ko.updateGroup(G)
                  Ticket = ko.reissueGroupTicket(msg.to)
                  
            elif msg.text in ["Kicker8","Sagiri join"]:
              if msg.from_ in admin:
                  X =cl.getGroup(msg.to)
                  X.preventJoinByYicket = False
                  cl.updateGroup(X)
                  invsend = 0
                  Ti = cl.reissueGroupTicket(msg.to)
                  ke.acceptGroupInvitationByTicket(msg.to,Ti)
                  G = ke.getGroup(msg.to)
                  G.preventJoinByTicket = True
                  ke.updateGroup(G)
                  Ticket = ke.reissueGroupTicket(msg.to)
           
            elif msg.text in ["Kicker9","Erio join"]:
              if msg.from_ in admin:
                  X =cl.getGroup(msg.to)
                  X.preventJoinByYicket = False
                  cl.updateGroup(X)
                  invsend = 0
                  Ti = cl.reissueGroupTicket(msg.to)
                  ku.acceptGroupInvitationByTicket(msg.to,Ti)
                  G = ku.getGroup(msg.to)
                  G.preventJoinByTicket = True
                  ku.updateGroup(G)
                  Ticket = ku.reissueGroupTicket(msg.to)      
 
            elif msg.text in ["Kicker10","Mirai join"]:
              if msg.from_ in admin:
                  X =cl.getGroup(msg.to)
                  X.preventJoinByYicket = False
                  cl.updateGroup(X)
                  invsend = 0
                  Ti = cl.reissueGroupTicket(msg.to)
                  kv.acceptGroupInvitationByTicket(msg.to,Ti)
                  G = kv.getGroup(msg.to)
                  G.preventJoinByTicket = True
                  kv.updateGroup(G)
                  Ticket = kv.reissueGroupTicket(msg.to)
                  
            elif msg.text in ["Kicker11","Sakura join"]:
              if msg.from_ in admin:
                  X =cl.getGroup(msg.to)
                  X.preventJoinByYicket = False
                  cl.updateGroup(X)
                  invsend = 0
                  Ti = cl.reissueGroupTicket(msg.to)
                  kw.acceptGroupInvitationByTicket(msg.to,Ti)
                  G = kw.getGroup(msg.to)
                  G.preventJoinByTicket = True
                  kw.updateGroup(G)
                  Ticket = kw.reissueGroupTicket(msg.to)
                 
            elif msg.text in ["Kicker12","Mitsuki join"]:
              if msg.from_ in admin:
                  X =cl.getGroup(msg.to)
                  X.preventJoinByYicket = False
                  cl.updateGroup(X)
                  invsend = 0
                  Ti = cl.reissueGroupTicket(msg.to)
                  kx.acceptGroupInvitationByTicket(msg.to,Ti)
                  G = kx.getGroup(msg.to)
                  G.preventJoinByTicket = True
                  kx.updateGroup(G)
                  Ticket = kx.reissueGroupTicket(msg.to)

            elif msg.text in ["Sini"]:
              if msg.from_ in admin:
                  ginfo = ki.getGroup(msg.to)
                  ki.acceptGroupInvitation(msg.to)
                  kk.acceptGroupInvitation(msg.to)
                  kc.acceptGroupInvitation(msg.to)
                  ks.acceptGroupInvitation(msg.to)
                  ka.acceptGroupInvitation(msg.to)
                  kb.acceptGroupInvitation(msg.to)
                  ko.acceptGroupInvitation(msg.to)
                  ke.acceptGroupInvitation(msg.to)
                  ku.acceptGroupInvitation(msg.to)
                  kv.acceptGroupInvitation(msg.to)
                  kw.acceptGroupInvitation(msg.to)
                  kx.acceptGroupInvitation(msg.to)
                  print "Kicker Acc invit\n" + str(ginfo.name)
#======================================================# 
    #-------------Fungsi Leave Group Start---------------#
            elif msg.text in ["Leave","Cabut"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    ginfo = cl.getGroup(msg.to)
                    try:
                    	ki.sendText(msg.to, "Sayonara " + str(ginfo.name))
                        ki.leaveGroup(msg.to)
                        kk.leaveGroup(msg.to)
                        kc.leaveGroup(msg.to)
                        ks.leaveGroup(msg.to)
                        ka.leaveGroup(msg.to)
                        kb.leaveGroup(msg.to)
                        ko.leaveGroup(msg.to)
                        ke.leaveGroup(msg.to)
                        ku.leaveGroup(msg.to)
                        kv.leaveGroup(msg.to)
                        kw.leaveGroup(msg.to)
                        kx.leaveGroup(msg.to)
                        #ky.leaveGroup(msg.to)
                    except:
                        pass
            elif msg.text in ["Leave1","Ram leave"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    ginfo = cl.getGroup(msg.to)
                    try:
                        ki.leaveGroup(msg.to)
                    except:
                        pass
            elif msg.text in ["Leave2","Rem leave"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    ginfo = cl.getGroup(msg.to)
                    try:
                        kk.leaveGroup(msg.to)
                    except:
                        pass
            elif msg.text in ["Leave3","Emilia leave"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    ginfo = cl.getGroup(msg.to)
                    try:
                        kc.leaveGroup(msg.to)
                    except:
                        pass
            elif msg.text in ["Leave4","Raphi leave"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    ginfo = cl.getGroup(msg.to)
                    try:
                        ks.leaveGroup(msg.to)
                    except:
                        pass
            elif msg.text in ["Leave5","Gabriel leave"]:
                if msg.toType == 2:
                    ginfo = cl.getGroup(msg.to)
                    try:
                        ka.leaveGroup(msg.to)
                    except:
                        pass
            elif msg.text in ["Leave6","Vigne leave"]:
                if msg.toType == 2:
                    ginfo = cl.getGroup(msg.to)
                    try:
                        kb.leaveGroup(msg.to)
                    except:
                        pass
            elif msg.text in ["Leave7","Satania leave"]:
                if msg.toType == 2:
                    ginfo = cl.getGroup(msg.to)
                    try:
                        ko.leaveGroup(msg.to)
                    except:
                        pass
            elif msg.text in ["Leave8","Sagiri leave"]:
                if msg.toType == 2:
                    ginfo = cl.getGroup(msg.to)
                    try:
                        ke.leaveGroup(msg.to)
                    except:
                        pass
            elif msg.text in ["Leave9","Erio leave"]:
                if msg.toType == 2:
                    ginfo = cl.getGroup(msg.to)
                    try:
                        ku.leaveGroup(msg.to)
                    except:
                        pass
            elif msg.text in ["Leave10","Mirai leave"]:
                if msg.toType == 2:
                    ginfo = cl.getGroup(msg.to)
                    try:
                        kv.leaveGroup(msg.to)
                    except:
                        pass
            elif msg.text in ["Leave11","Sakura leave"]:
                if msg.toType == 2:
                    ginfo = cl.getGroup(msg.to)
                    try:
                        kw.leaveGroup(msg.to)
                    except:
                        pass
            elif msg.text in ["Leave12","Mitsuki leave"]:
                if msg.toType == 2:
                    ginfo = cl.getGroup(msg.to)
                    try:
                        kx.leaveGroup(msg.to)
                    except:
                        pass
#--------------------------------------------------------------
            elif "Leave from:" in msg.text:
              if msg.from_ in Creator:
                saya = msg.text.replace("Leave from:","")
                gid = cl.getGroupIdsJoined()
                for i in gid:
                    h = cl.getGroup(i).name
                    if ginfo == saya:
                        ki.leaveGroup(i)
                        kk.leaveGroup(i)
                        kc.leaveGroup(i)
                        ks.leaveGroup(i)
                        ka.leaveGroup(i)
                        kb.leaveGroup(i)
                        ko.leaveGroup(i)
                        ke.leaveGroup(i)
                        ku.leaveGroup(i)
                        kv.leaveGroup(i)
                        kw.leaveGroup(i)
                        kx.leaveGroup(i)
                        cl.sendText(msg.to,"Done Leave From "+h+" ")
#--------------------------------------------------------------
            elif "Leave all group" == msg.text:
		gid = ki.getGroupIdsJoined()
                if msg.from_ in Creator:
		    for i in gid:
			ki.sendText(i,"Bot dipaksa pergi😭")
			ki.leaveGroup(i)
			kk.leaveGroup(i)
			kc.leaveGroup(i)
			ks.leaveGroup(i)
			ka.leaveGroup(i)
			kb.leaveGroup(i)
			ko.leaveGroup(i)
			ke.leaveGroup(i)
			ku.leaveGroup(i)
			kv.leaveGroup(i)
			kw.leaveGroup(i)
			kx.leaveGroup(i)
			#ky.leaveGroup(i)
		    cl.sendText(msg.to,"Done leave all group")
		else:
		    cl.sendText(msg.to,"Khusus Creator")

#--------------------------------------------------------
	    elif "Balik profile" in msg.text:
              if msg.from_ in Creator:
		try:
		    cl.updateDisplayPicture(backup.pictureStatus)
		    cl.updateProfile(backup)
		    cl.sendText(msg.to, "Profile telah dibackup semula")
		except Exception as e:
		    cl.sendText(msg.to, str(e))
#--------------------------------------------------------
	    elif "Clone " in msg.text:
              if msg.from_ in admin:
                copy0 = msg.text.replace("Clone ","")
                copy1 = copy0.lstrip()
                copy2 = copy1.replace("@","")
                copy3 = copy2.rstrip()
                _name = copy3
		group = cl.getGroup(msg.to)
		for contact in group.members:
		    cname = cl.getContact(contact.mid).displayName
		    if cname == _name:
			cl.CloneContactProfile(contact.mid)
			cl.sendText(msg.to, "Hoho...aku clone nya\n" + contact.displayName)
		    else:
			pass
#--------------------------------------------------------
	    elif "Ram backup" in msg.text:
		try:
		    ki.updateDisplayPicture(backupram.pictureStatus)
		    ki.updateProfile(backupram)
		    ki.sendText(msg.to, "Profile telah dibackup semula")
		except Exception as e:
		    ki.sendText(msg.to, str(e))
#--------------------------------------------------------
	    elif "Ram clone " in msg.text:
              if msg.from_ in Creator:
                copy0 = msg.text.replace("Ram clone ","")
                copy1 = copy0.lstrip()
                copy2 = copy1.replace("@","")
                copy3 = copy2.rstrip()
                _name = copy3
		group = ki.getGroup(msg.to)
		for contact in group.members:
		    cname = ki.getContact(contact.mid).displayName
		    if cname == _name:
			ki.CloneContactProfile(contact.mid)
			ki.sendText(msg.to, "Hoho...aku clone nya\n" + contact.displayName)
		    else:
			pass
#--------------------------------------------------------
	    elif "Rem backup" in msg.text:
		try:
		    kk.updateDisplayPicture(backuprem.pictureStatus)
		    kk.updateProfile(backuprem)
		    kk.sendText(msg.to, "Profile telah dibackup semula")
		except Exception as e:
		    ki.sendText(msg.to, str(e))
#--------------------------------------------------------
	    elif "Rem clone " in msg.text:
              if msg.from_ in Creator:
                copy0 = msg.text.replace("Rem clone ","")
                copy1 = copy0.lstrip()
                copy2 = copy1.replace("@","")
                copy3 = copy2.rstrip()
                _name = copy3
		group = kk.getGroup(msg.to)
		for contact in group.members:
		    cname = kk.getContact(contact.mid).displayName
		    if cname == _name:
			kk.CloneContactProfile(contact.mid)
			kk.sendText(msg.to, "Hoho...aku clone nya\n" + contact.displayName)
		    else:
			pass
#--------------------------------------------------------
	    elif "Emilia clone " in msg.text:
              if msg.from_ in Creator: 
                copy0 = msg.text.replace("Emilia clone ","")
                copy1 = copy0.lstrip()
                copy2 = copy1.replace("@","")
                copy3 = copy2.rstrip()
                _name = copy3
		group = kc.getGroup(msg.to)
		for contact in group.members:
		    cname = kc.getContact(contact.mid).displayName
		    if cname == _name:
			kc.CloneContactProfile(contact.mid)
			kc.sendText(msg.to, "Hoho...aku clone nya\n" + contact.displayName)
		    else:
			pass
#--------------------------------------------------------
	    elif "Mitsuki clone " in msg.text:
              if msg.from_ in Creator:
                copy0 = msg.text.replace("Mitsuki clone ","")
                copy1 = copy0.lstrip()
                copy2 = copy1.replace("@","")
                copy3 = copy2.rstrip()
                _name = copy3
		group = kx.getGroup(msg.to)
		for contact in group.members:
		    cname = kx.getContact(contact.mid).displayName
		    if cname == _name:
			kx.CloneContactProfile(contact.mid)
			kx.sendText(msg.to, "Hoho...aku clone nya\n" + contact.displayName)
		    else:
			pass
#--------------------------------------------------------
	    elif "Sakura clone " in msg.text:
              if msg.from_ in Creator:
                copy0 = msg.text.replace("Sakura clone ","")
                copy1 = copy0.lstrip()
                copy2 = copy1.replace("@","")
                copy3 = copy2.rstrip()
                _name = copy3
		group = kw.getGroup(msg.to)
		for contact in group.members:
		    cname = kw.getContact(contact.mid).displayName
		    if cname == _name:
			kw.CloneContactProfile(contact.mid)
			kw.sendText(msg.to, "Hoho...aku clone nya\n" + contact.displayName)
		    else:
			pass
#--------------------------------------------------------------------------------
            elif ("Cover " in msg.text):
              if msg.from_ in admin:
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        try:
                            contact = cl.getContact(target)
                            cu = cl.channel.getCover(target)
                            path = str(cu)
                            cl.sendText(msg.to,"Cover " + contact.displayName)
                            cl.sendImageWithURL(msg.to,path)
                        except Exception as error:
                            print error
#------------------------------------------------------------------
            elif ("Pic " in msg.text):
              if msg.from_ in admin:
                    targets = []
                    key = eval(msg.contentMetadata["MENTION"])
                    key["MENTIONEES"][0]["M"]
                    for x in key["MENTIONEES"]:
                        targets.append(x["M"])
                    for target in targets:
                        try:
                            contact = cl.getContact(target)
                            image = "http://dl.profile.line-cdn.net/" + contact.pictureStatus
                            cl.sendText(msg.to,"Profile Picture " + contact.displayName)
                            cl.sendImageWithURL(msg.to,image)
                        except Exception as error:
                            print error
#===============================================================================#
            elif msg.text in ["Steal"]:
              if msg.from_ in admin:
                wait["stealcontact"] = True
                cl.sendText(msg.to,"Send Contact")
#===============================================================================#
            elif "Pict group " in msg.text:
            	try:
                     saya = msg.text.replace("Pict group ","")
                     gid = cl.getGroupIdsJoined()
                     for i in gid:
                         h = cl.getGroup(i).name
                         gna = cl.getGroup(i)
                         if h == saya:
                             cl.sendImageWithURL(msg.to,"http://dl.profile.line.naver.jp/"+ gna.pictureStatus)       
                except Exception as error:
                 	print error
#======================================================#
            elif "Image " in msg.text:
                search = msg.text.replace("Image ","")
                url = 'https://www.google.com/search?espv=2&biw=1366&bih=667&tbm=isch&oq=kuc&aqs=mobile-gws-lite.0.0l5&q=' + search
                raw_html = (download_page(url))
                items = []
                items = items + (_images_get_all_items(raw_html))
                path = random.choice(items)
                print path
                try:
                    cl.sendText(msg.to,"Tunggu Bentar....")
                    cl.sendImageWithURL(msg.to,path)
                except:
                    pass
#======================================================#
            elif "Pap" in msg.text:
                try:
                    search = msg.text.replace("Pap","")
                    url = 'http://pm1.narvii.com/5785/808a983acb2e5b55395e6a32c800c243ca6c8107_hq.jpg' + search
                    path = random.choice(url)
                    print path
                    cl.sendText(msg.to, "Wait cekrek dulu....")
                    cl.sendImageWithURL(msg.to, path)
                except Exception as error:
                    print error

                
            elif "Getig " in msg.text:
                    try:
                    	instagram = msg.text.replace("Getig ","")
                        response = requests.get("https://www.instagram.com/"+instagram+"?__a=1")
                        data = response.json()
                        namaIG = str(data['user']['full_name'])
                        bioIG = str(data['user']['biography'])
                        mediaIG = str(data['user']['media']['count'])
                        verifIG = str(data['user']['is_verified'])
                        usernameIG = str(data['user']['username'])
                        followerIG = str(data['user']['followed_by']['count'])
                        profileIG = data['user']['profile_pic_url_hd']
                        privateIG = str(data['user']['is_private'])
                        followIG = str(data['user']['follows']['count'])
                        text = "Name : "+namaIG+"\nBiography :\n"+bioIG+"\nFollower : "+followerIG+"\nFollowing : "+followIG+"\nMedia : "+mediaIG+"\nVerified : "+verifIG+"\nPrivate : "+privateIG+"\nUsername : "+usernameIG+""
                        cl.sendImageWithURL(msg.to, profileIG)
                        cl.sendText(msg.to, str(text))
                    except Exception as e:
                        cl.sendText(msg.to, str(e))
            
#======================================================#
            elif "English " in msg.text:
                bahasa_awal = 'id'
                bahasa_tujuan = 'en'
                kata = msg.text.replace("Id@en ","")
                url = 'https://translate.google.com/m?sl=%s&tl=%s&ie=UTF-8&prev=_m&q=%s' % (bahasa_awal, bahasa_tujuan, kata.replace(" ", "+"))
                agent = {'User-Agent':'Mozilla/5.0'}
                cari_hasil = 'class="t0">'
                request = urllib2.Request(url, headers=agent)
                page = urllib2.urlopen(request).read()
                result = page[page.find(cari_hasil)+len(cari_hasil):]
                result = result.split("<")[0]
                cl.sendText(msg.to,"~~~~~FROM ID~~~~~\n" + "" + kata + "\n~~~~~TO EN~~~~~\n" + "" + result)
#======================================================#
            elif "Japanese " in msg.text:
                bahasa_awal = 'ja'
                bahasa_tujuan = 'id'
                kata = msg.text.replace("ja@id ","")
                url = 'https://translate.google.com/m?sl=%s&tl=%s&ie=UTF-8&prev=_m&q=%s' % (bahasa_awal, bahasa_tujuan, kata.replace(" ", "+"))
                agent = {'User-Agent':'Mozilla/5.0'}
                cari_hasil = 'class="t0">'
                request = urllib2.Request(url, headers=agent)
                page = urllib2.urlopen(request).read()
                result = page[page.find(cari_hasil)+len(cari_hasil):]
                result = result.split("<")[0]
                cl.sendText(msg.to,"~~~~~FROM JA~~~~~\n" + "" + kata + "\n~~~~~TO ID~~~~~\n" + "" + result)
##########Kalau gak suka instal module translate atau sejenisnya
#-----------------------------------------------
            elif "Vn " in msg.text:
                 psn = msg.text.replace("Vn ","")
                 tts = gTTS(psn, lang='id', slow=False)
                 tts.save('tts.mp3')
                 cl.sendAudio(msg.to, 'tts.mp3')
#-----------------------------------------------
            elif "VnJa " in msg.text:
                 psn = msg.text.replace("VnJa ","")
                 tts = gTTS(psn, lang='ja', slow=False)
                 tts.save('tts.mp3')
                 cl.sendAudio(msg.to, 'tts.mp3')
#Tau work apa kagak (haha) kalau ada yg salah koreksi yah

#Cara pemakaian Say@Negara: text
#------------------------------------------------------------------
            elif ("Music " in msg.text):
                songname = msg.text.replace("Music ","")
                params = {"songname": songname}
                r = requests.get('http://ide.fdlrcn.com/workspace/yumi-apis/joox?' + urllib.urlencode(params))
                data = r.text
                data = json.loads(data)
                for song in data:
                    abc = song[3].replace('https://','http://')
                    cl.sendText(msg.to, "Judul: " + song[0].encode('utf-8') +"" + "\n" + "Durasi: " + song[1].encode('utf-8') +"" + "\n" + "Link: " + song[4].encode('utf-8'))
                    cl.sendText(msg.to, "Tunggu Bentar....")
                    cl.sendAudioWithURL(msg.to, abc)
                    
#------------------------------------------------------------------
            elif ("Rem music " in msg.text):
                songname = msg.text.replace("Music ","")
                params = {"songname": songname}
                r = requests.get('http://ide.fdlrcn.com/workspace/yumi-apis/joox?' + urllib.urlencode(params))
                data = r.text
                data = json.loads(data)
                for song in data:
                    abc = song[3].replace('https://','http://')
                    kk.sendText(msg.to, "Judul: " + song[0].encode('utf-8') +"" + "\n" + "Durasi: " + song[1].encode('utf-8') +"" + "\n" + "Link: " + song[4].encode('utf-8'))
                    kk.sendText(msg.to, "Tunggu Bentar....")
                    kk.sendAudioWithURL(msg.to, abc)
                    
            elif "Getlirik " in msg.text:
                songname = msg.text.replace("Getlirik ","")
                params = {"songname": songname}
                r=requests.get('http://ide.fdlrcn.com/workspace/yumi-apis/joox?' + urllib.urlencode(params))
                data=r.text
                data=json.loads(data)
                for song in data:
                    songz = song[5].encode('utf-8')
                    lyric = songz.replace('ti:','Judul - ')
                    lyric = lyric.replace('ar:','Artis - ')
                    lyric = lyric.replace('al:','Album - ')
                    lyric = lyric.replace('by:','')
                    removeString = "[1234567890.:]"
                    for char in removeString:
                        lyric = lyric.replace(char,'')
                    cl.sendText(msg.to,lyric)
                    
            elif "Rem lirik " in msg.text:
                songname = msg.text.replace("Getlirik ","")
                params = {"songname": songname}
                r=requests.get('http://ide.fdlrcn.com/workspace/yumi-apis/joox?' + urllib.urlencode(params))
                data=r.text
                data=json.loads(data)
                for song in data:
                    songz = song[5].encode('utf-8')
                    lyric = songz.replace('ti:','Judul - ')
                    lyric = lyric.replace('ar:','Artis - ')
                    lyric = lyric.replace('al:','Album - ')
                    lyric = lyric.replace('by:','')
                    removeString = "[1234567890.:]"
                    for char in removeString:
                        lyric = lyric.replace(char,'')
                    kk.sendText(msg.to,lyric)
#======================================================# 
            elif "Youtube " in msg.text.lower():
                   query = msg.text.replace("Youtube ","")
                   try:
                       if len(query) == 3:
                           isi = yt(query[2])
                           hasil = isi[int(query[1])-1]
                           print hasil
                           cl.sendText(msg.to, "Tunggu Bentar....")
                           cl.sendText(msg.to,hasil)
                       else:
                           isi = yt(query[1])
                           print isi
                           cl.sendText(msg.to,isi[0])
                   except Exception as error:
                           print error
            elif 'Yt ' in msg.text:
                try:
                    textToSearch = (msg.text).replace('Yt ', "").strip()
                    query = urllib.quote(textToSearch)
                    url = "https://www.youtube.com/results?search_query=" + query
                    response = urllib2.urlopen(url)
                    html = response.read()
                    soup = BeautifulSoup(html, "html.parser")
                    results = soup.find(attrs={'class':'yt-uix-tile-link'})
                    path = 'https://www.youtube.com' + results['href']
                    cl.sendText(msg.to,'https://www.youtube.com' + results['href'])
                    cl.sendText(msg.to,"Wait To Send Video")
                    cl.sendVideoWithURL(msg.to, path)
                except Exception as e:
                	 cl.sendText(msg.to, str(e))
            elif "Video " in msg.text:
                try:
                    search = msg.text.replace("Vidio ","")
                    query = urllib.quote(search)
                    url = 'https://www.youtube.com/results?search_query=' + query
                    response = urllib2.urlopen(url)
                    html = response.read()
                    soup = BeautifulSoup(html, "html.parser")
                    results = soup.find(attrs={'class':'yt-uix-tile-link'})
                    path = 'https://www.youtube.com' + results['href']
                    print path
                    cl.sendText(msg.to, "Tunggu Bentar...")
                    cl.sendVideoWithURL(msg.to, path)
                except Exception as e:
                    cl.sendText(msg.to, str(e))
#======================================================#
            elif ("Zkick " in msg.text):
               if msg.from_ in admin:
                   targets = []
                   key = eval(msg.contentMetadata["MENTION"])
                   key["MENTIONEES"] [0] ["M"]
                   for x in key["MENTIONEES"]:
                       targets.append(x["M"])
                   for target in targets:
                       try:
                           klist=[kk,kc,ks,ka,kb,ko,ke,ku,kv]
                           kicker=random.choice(klist)
                           kicker.kickoutFromGroup(msg.to,[target])
                           print (msg.to,[g.mid])
                       except:
                           pass              
            elif ("Hushus " in msg.text):
               if msg.from_ in admin:
                   targets = []
                   key = eval(msg.contentMetadata["MENTION"])
                   key["MENTIONEES"] [0] ["M"]
                   for x in key["MENTIONEES"]:
                       targets.append(x["M"])
                   for target in targets:
                       try:
                           cl.kickoutFromGroup(msg.to,[target])
                           klist=[cl]
                           kicker=random.choice(klist)
                           kicker.kickoutFromGroup(msg.to,[target])
                           print (msg.to,[g.mid])
                       except:
                           pass
#======================================================# 
    #-------------Fungsi Tagall User -------------#
            elif msg.text in ["Hai"]:
              if msg.from_ in admin:
                group = cl.getGroup(msg.to)
                nama = [contact.mid for contact in group.members]
                nm1, nm2, nm3, nm4, nm5, jml = [], [], [], [], [], len(nama)
                if jml <= 100:
                    mention(msg.to, nama)
                    if jml > 100 and jml < 200:
                        for i in range(0, 100):
                            nm1 += [nama[i]]
                    mention(msg.to, nm1)
                    for j in range(101, len(nama)):
                        nm2 += [nama[j]]
                    mention(msg.to, nm2)
                if jml > 200 and jml < 300:
                    for i in range(0, 100):
                        nm1 += [nama[i]]
                    mention(msg.to, nm1)
                    for j in range(101, 200):
                        nm2 += [nama[j]]
                    mention(msg.to, nm2)
                    for k in range(201, len(nama)):
                        nm3 += [nama[k]]
                    mention(msg.to, nm3)
                if jml > 300 and jml < 400:
                    for i in range(0, 100):
                        nm1 += [nama[i]]
                    mention(msg.to, nm1)
                    for j in range(101, 200):
                        nm2 += [nama[j]]
                    mention(msg.to, nm2)
                    for k in range(201, 300):
                        nm3 += [nama[k]]
                    mention(msg.to, nm3)
                    for l in range(301, len(nama)):
                        nm4 += [nama[l]]
                    mention(msg.to, nm4)
                if jml > 400 and jml < 500:
                    for i in range(0, 100):
                        nm1 += [nama[i]]
                    mention(msg.to, nm1)
                    for j in range(101, 200):
                        nm2 += [nama[j]]
                    mention(msg.to, nm2)
                    for k in range(201, 300):
                        nm3 += [nama[k]]
                    mention(msg.to, nm3)
                    for l in range(301, 400):
                        nm4 += [nama[l]]
                    mention(msg.to, nm4)
                    for h in range(401, len(nama)):
                        nm5 += [nama[h]]
                    mention(msg.to, nm5)
                if jml > 500:
                    cl.sendText(msg.to,'Member melebihi batas.')
                    cnt = Message()
                    cnt.text = "Done : " + str(jml) +  " Members"
                    cnt.to = msg.to
                    cl.sendMessage(cnt)
                    
            elif msg.text in ["Mention"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    group = cl.getGroup(msg.to)
                    nama = [contact.mid for contact in group.members]
                    cb = ""
                    cb3 = ""
                    strt = int(0)
                    akh = int(0)
                    for md in nama:
                        akh = akh + int(5)
                        cb += """{"S":"""+json.dumps(str(strt))+""","E":"""+json.dumps(str(akh))+""","M":"""+json.dumps(md)+"},"""
                        strt = strt + int(6)
                        akh = akh + 1
                        cb3 += "@nlia\n"
                    cb = (cb[:int(len(cb)-1)])
                    msg.contentType = 0
                    msg.text = cb3
                    msg.contentMetadata ={'MENTION':'{"MENTIONEES":['+cb+']}','EMTVER':'4'}
                    try:
                        cl.sendMessage(msg)
                    except Exception as error:
                        print error

            elif msg.text in ["Ram mention","Woi"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    group = cl.getGroup(msg.to)
                    nama = [contact.mid for contact in group.members]
                    cb = ""
                    cb2 = ""
                    strt = int(0)
                    akh = int(0)
                    for md in nama:
                        akh = akh + int(5)
                        cb += """{"S":"""+json.dumps(str(strt))+""","E":"""+json.dumps(str(akh))+""","M":"""+json.dumps(md)+"},"""
                        strt = strt + int(6)
                        akh = akh + 1
                        cb2 += "@nlia\n"
                    cb = (cb[:int(len(cb)-1)])
                    msg.contentType = 0
                    msg.text = cb2
                    msg.contentMetadata ={'MENTION':'{"MENTIONEES":['+cb+']}','EMTVER':'4'}
                    try:
                        ki.sendMessage(msg)
                    except Exception as error:
                        print error
#--------------------------------------------------------------#
            elif msg.text in ["Kill "]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    group = ki.getGroup(msg.to)
                    gMembMids = [contact.mid for contact in group.members]
                    matched_list = []
                    for tag in wait["blacklist"]:
                        matched_list+=filter(lambda str: str == tag, gMembMids)
                    if matched_list == []:
                        kc.sendText(msg.to,"Selamat tinggal")
                        return
                    for jj in matched_list:
                        try:
                            klist=[ki,kk,kc,ks,kb,ko,ke,ku,kv,kw]
                            kicker=random.choice(klist)
                            kicker.kickoutFromGroup(msg.to,[jj])
                            print (msg.to,[jj])
                        except:
                            pass
#--------------------------------------------------------------#       
            elif ("Destroy" in msg.text):
              if msg.from_ in admin:
                if msg.toType == 2:
                    print "ok"
                    _name = msg.text.replace("Destroy","")
                    gs = ki.getGroup(msg.to)
                    gs = kk.getGroup(msg.to)
                    gs = kc.getGroup(msg.to)
                    gs = ks.getGroup(msg.to)
                    ki.sendText(msg.to,"🔸We come to destroy your group🔸")
                    kb.sendText(msg.to,"Relax slow slow no baper...😂😂")
                    kc.sendText(msg.to,"Kenapa diem aja?")
                    ks.sendText(msg.to,"Tangkis Bego Jangan Gemeter...😘")
                    targets = []
                    for g in gs.members:
                        if _name in g.displayName:
                            targets.append(g.mid)
                    if targets == []:
                        ki.sendText(msg.to,"Error􀜁􀅔Har Har􏿿")
                    else:
                        for target in targets:
                          if target not in Bots:
                            try:
                                klist=[ki,kk,kc,ks,ka,kb,ko,ku]
                                kicker=random.choice(klist)
                                kicker.kickoutFromGroup(msg.to,[target])
                                print (msg.to,[g.mid])
                            except:
                                cl.sendText(msg.to,"Hm..")
#--------------------------------------------------------------#
            elif "Nk " in msg.text:
                  if msg.from_ in admin:
                       nk0 = msg.text.replace("Nk ","")
                       nk1 = nk0.lstrip()
                       nk2 = nk1.replace("@","")
                       nk3 = nk2.rstrip()
                       _name = nk3
                       gs = cl.getGroup(msg.to)
                       targets = []
                       for s in gs.members:
                           if _name in s.displayName:
                              targets.append(s.mid)
                       if targets == []:
                           sendMessage(msg.to,"Target tdk ada")
                           pass
                       else:
                           for target in targets:
                                try:
                                    klist=[cl,ki,kk,kc,ka,kb,ko,ke,kv]
                                    kicker=random.choice(klist)
                                    kicker.kickoutFromGroup(msg.to,[target])
                                    print (msg.to,[g.mid])
                                except:
                                    pass
#--------------------------------------------------------------#
            elif "Ban @" in msg.text:
              if msg.from_ in admin:
                if msg.toType == 2:
                    print "[Banned] Sukses"
                    _name = msg.text.replace("Ban @","")
                    _nametarget = _name.rstrip('  ')
                    gs = cl.getGroup(msg.to)
                    gs = ki.getGroup(msg.to)
                    gs = kk.getGroup(msg.to)
                    gs = kc.getGroup(msg.to)
                    targets = []
                    for g in gs.members:
                        if _nametarget == g.displayName:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendText(msg.to,"Target tdk ditemukan")
                    else:
                        for target in targets:
                            try:
                                wait["blacklist"][target] = True
                                f=codecs.open('st2__b.json','w','utf-8')
                                json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                                cl.sendText(msg.to,"Done sukses blacklist")
                            except:
                                ki.sendText(msg.to,"Error")
#--------------------------------------------------------------#
            #----------------Fungsi Unbanned User Target Start-----------------------#
            elif "Unban @" in msg.text:
              if msg.from_ in admin:
                if msg.toType == 2:
                    print "[Unban] Sukses"
                    _name = msg.text.replace("Unban @","")
                    _nametarget = _name.rstrip('  ')
                    gs = cl.getGroup(msg.to)
                    targets = []
                    for g in gs.members:
                        if _nametarget == g.displayName:
                            targets.append(g.mid)
                    if targets == []:
                        cl.sendText(msg.to,"Target tdk ada")
                    else:
                        for target in targets:
                            try:
                                del wait["blacklist"][target]
                                f=codecs.open('st2__b.json','w','utf-8')
                                json.dump(wait["blacklist"], f, sort_keys=True, indent=4,ensure_ascii=False)
                                cl.sendText(msg.to,"Done Deleted Blacklist")
                            except:
                                ki.sendText(msg.to,"Error")
#======================================================# 
        #-------------Fungsi Spam Start---------------------#
            elif msg.text in ["Gc apa ini","Grup apaan ini","Ini apa?"]:
                ki.sendText(msg.to,"Ya group chat lah")
                kk.sendText(msg.to,"􀜁􀄃Hooh Ini Grup Chat")
                kc.sendText(msg.to,"Iya klo dh tau Grup chat Ga usah banyak tanya:v")
#--------------------------------------------------------------#
            elif msg.text in ["haha","Haha","Haa..."]:
                ki.sendText(msg.to," 􀜁􀅔Har Har􏿿。􏿿")
                kk.sendText(msg.to," 􀜁􀅔􀜁􀅔Har Har􏿿")
                kc.sendText(msg.to,"􀜁􀅔􀜁􀅔Har Har􏿿")
                ks.sendText(msg.to," 􀜁􀅔􀜁􀅔Har Har􏿿")
                ka.sendText(msg.to,"􀜁􀅔Har Har􏿿")
                kb.sendText(msg.to,"􀜁􀅔Har Har􏿿")
                ko.sendText(msg.to,"􀜁􀅔Har Har􏿿")
                ke.sendText(msg.to,"􀜁􀅔Har Har􏿿")
                ku.sendText(msg.to,"􀜁􀅔Har Har􏿿")
                kv.sendText(msg.to,"􀜁􀅔Har Har􏿿")
                kw.sendText(msg.to,"􀜁􀅔Har Har􏿿")
                kx.sendText(msg.to,"􀜁􀅔Har Har􏿿")
#======================================================# 
            elif "," in msg.text:
                cl.sendText(msg.to, "WOI......!!!!")
                cl.sendText(msg.to, "AKU DATANG LAGI...!!!!\n👋😁")
                cl.sendText(msg.to, "=========================")
                cl.sendText(msg.to, "WOI......!!!!")
                cl.sendText(msg.to, "AKU PERGI LAGI....!!!!!!\n😥😥") 
               
            elif "Anu" in msg.text:
                ki.sendText(msg.to, "WOI......!!!!")
                kk.sendText(msg.to, "AKU DATANG LAGI...!!!!\n👋😁")
                kc.sendText(msg.to, "=========================")
                kv.sendText(msg.to, "WOI......!!!!")
                ko.sendText(msg.to, "AKU PERGI LAGI....!!!!!!\n😥😥")
                
            elif "Ram say " in msg.text:
                bctxt = msg.text.replace("Ram say ","")
                ki.sendText(msg.to,(bctxt))
            elif "Rem say " in msg.text:
                bctxt = msg.text.replace("Rem say ","")
                kk.sendText(msg.to,(bctxt))
            elif "Emilia say " in msg.text:
                bctxt = msg.text.replace("Emilia say ","")
                kc.sendText(msg.to,(bctxt))
            elif "Raphi say " in msg.text:
                bctxt = msg.text.replace("Raphi say ","")
                ks.sendText(msg.to,(bctxt))
            elif "Gabriel say " in msg.text:
                bctxt = msg.text.replace("Gabriel say ","")
                ka.sendText(msg.to,(bctxt))
            elif "Vigne say " in msg.text:
                bctxt = msg.text.replace("Vigne say ","")
                kb.sendText(msg.to,(bctxt))
            elif "Satania say " in msg.text:
                bctxt = msg.text.replace("Satania say ","")
                ko.sendText(msg.to,(bctxt))
            elif "Sagiri say " in msg.text:
                bctxt = msg.text.replace("Sagiri say ","")
                ke.sendText(msg.to,(bctxt))
            elif "Erio say " in msg.text:
                bctxt = msg.text.replace("Erio say ","")
                ku.sendText(msg.to,(bctxt))
            elif "Mirai say " in msg.text:
                bctxt = msg.text.replace("Mirai say ","")
                kv.sendText(msg.to,(bctxt))
            elif "Sakura say " in msg.text:
                bctxt = msg.text.replace("Sakura say ","")
                kw.sendText(msg.to,(bctxt))
            elif "Mitsuki say " in msg.text:
                bctxt = msg.text.replace("Mitsuki say ","")
                kx.sendText(msg.to,(bctxt))
            elif "Say " in msg.text:
		bctxt = msg.text.replace("Say ","")
		ki.sendText(msg.to,(bctxt))
		kk.sendText(msg.to,(bctxt))
		kc.sendText(msg.to,(bctxt))
                ks.sendText(msg.to,(bctxt))
                ka.sendText(msg.to,(bctxt))
                ko.sendText(msg.to,(bctxt))
                kb.sendText(msg.to,(bctxt))
                ke.sendText(msg.to,(bctxt))
                ku.sendText(msg.to,(bctxt))
                kv.sendText(msg.to,(bctxt))
                kw.sendText(msg.to,(bctxt))
                kx.sendText(msg.to,(bctxt))
                #ky.sendText(msg.to,(bctxt))
#======================================================# 
            elif msg.text in ["Respon","Absen"]:
              if msg.from_ in admin:
                cl.sendText(msg.to,"Absen woi buru² ah lama")
                ki.sendText(msg.to,"Ram􀜁􀅔Har Har􏿿")
                kk.sendText(msg.to,"Rem􀜁􀅔Har Har􏿿")
                kc.sendText(msg.to,"Emilia􀜁􀅔Har Har􏿿")
                ks.sendText(msg.to,"Raphi􀜁􀅔Har Har􏿿")
                ka.sendText(msg.to,"Gabriel􀜁􀅔Har Har􏿿")
                kb.sendText(msg.to,"Vigne􀜁􀅔Har Har􏿿")
                ko.sendText(msg.to,"Satania􀜁􀅔Har Har􏿿")
                ke.sendText(msg.to,"Sagiri􀜁􀅔Har Har􏿿")
                ku.sendText(msg.to,"Erio􀜁􀅔Har Har􏿿")
                kv.sendText(msg.to,"Mirai􀜁􀅔Har Har􏿿")
                kw.sendText(msg.to,"Sakura􀜁􀅔Har Har􏿿")
                kx.sendText(msg.to,"Mitsuki􀜁􀅔Har Har􏿿")
#--------------------------------------------------------------#
            elif msg.text in ["Cek name"]:
              if msg.from_ in admin:
                profile = ki.getProfile()
                text = profile.displayName + "􀜁􀅔􏿿􀜁􀅔Har Har􏿿"
                ki.sendText(msg.to, text)
                
                profile = kk.getProfile()
                text = profile.displayName + "􀜁􀅔􏿿􀜁􀅔Har Har􏿿"
                kk.sendText(msg.to, text)
                
                profile = kc.getProfile()
                text = profile.displayName + "􀜁􀅔􏿿􀜁􀅔Har Har􏿿"
                kc.sendText(msg.to, text)
                
                profile = ks.getProfile()
                text = profile.displayName + "􀜁􀅔􏿿􀜁􀅔Har Har􏿿"
                ks.sendText(msg.to, text)
                
                profile = ka.getProfile()
                text = profile.displayName + "􀜁􀅔Har Har􏿿􀜁􀅔􏿿"
                ka.sendText(msg.to, text)
                
                profile = kb.getProfile()
                text = profile.displayName + "􀜁􀅔Har Har􏿿􀜁􀅔􏿿"
                kb.sendText(msg.to, text)
                
                profile = ko.getProfile()
                text = profile.displayName + "􀜁􀅔Har Har􏿿􀜁􀅔􏿿"
                ko.sendText(msg.to, text)
                
                profile = ke.getProfile()
                text = profile.displayName + "􀜁􀅔Har Har􏿿􀜁􀅔􏿿"
                ke.sendText(msg.to, text)
                
                profile = ku.getProfile()
                text = profile.displayName + "􀜁􀅔Har Har􏿿􀜁􀅔􏿿"
                ku.sendText(msg.to, text)
                
                profile = kv.getProfile()
                text = profile.displayName + "􀜁􀅔Har Har􏿿􀜁􀅔􏿿"
                kv.sendText(msg.to, text)
                
                profile = kw.getProfile()
                text = profile.displayName + "􀜁􀅔Har Har􏿿􀜁􀅔􏿿"
                kw.sendText(msg.to, text)
                
                profile = kx.getProfile()
                text = profile.displayName + "􀜁􀅔Har Har􏿿􀜁􀅔􏿿"
                kx.sendText(msg.to, text)
#--------------------------------------------------------------#         
            elif msg.text in ["PING","Ping","ping"]:
                ki.sendText(msg.to,"PONG 􀨁􀄻double thumbs up􏿿􀜁􀅔Har Har􏿿")
                kk.sendText(msg.to,"PONG 􀨁􀄻double thumbs up􏿿􀜁􀅔Har Har􏿿")
                kc.sendText(msg.to,"PONG 􀨁􀄻double thumbs up􏿿􀜁􀅔Har Har􏿿")
                ks.sendText(msg.to,"PONG 􀨁􀄻double thumbs up􏿿􀜁􀅔Har Har􏿿")
                ka.sendText(msg.to,"PONG 􀨁􀄻double thumbs up􏿿􀜁􀅔Har Har􏿿")
                kb.sendText(msg.to,"PONG 􀨁􀄻double thumbs up􏿿􀜁􀅔Har Har􏿿")
                ko.sendText(msg.to,"PONG 􀨁􀄻double thumbs up􏿿􀜁􀅔Har Har􏿿")
                ku.sendText(msg.to,"PONG 􀨁􀄻double thumbs up??􀜁􀅔Har Har􏿿")
                ke.sendText(msg.to,"PONG 􀨁􀄻double thumbs up􏿿􀜁􀅔Har Har􏿿")
                ku.sendText(msg.to,"PONG 􀨁􀄻double thumbs up􏿿􀜁􀅔Har Har􏿿")
                kv.sendText(msg.to,"PONG 􀨁􀄻double thumbs up􏿿􀜁􀅔Har Har􏿿")
                kw.sendText(msg.to,"PONG 􀨁􀄻double thumbs up􏿿􀜁􀅔Har Har􏿿")
                kx.sendText(msg.to,"PONG 􀨁􀄻double thumbs up􏿿􀜁􀅔Har Har􏿿")
                #ky.sendText(msg.to,"PONG 􀨁􀄻double thumbs up􏿿􀜁􀅔Har Har􏿿")
#--------------------------------------------------------------#
            elif msg.text in ["Njirr","Up","up"]:
                cl.sendText(msg.to,"Up\n\n\n\n\n\n\nUp\n\n\n\n\n\n\nUp\n\n\n\n\n\n\nUp\n\n\n\n\n\n\nUp\n\n\n\n\n\n\nUp\n\n\n\n\n\n\nUp\n\n\n\n\n\n\nUp\n\n\n\n\n\n\nUp\n\n\n\n\n\n\nUp")
#----------------- FUNGSI SPAM---------------------#
            elif "Bom @" in msg.text:
              if msg.from_ in admin: 
                _name = msg.text.replace("Bom @","")
                _nametarget = _name.rstrip(' ')
                gs = cl.getGroup(msg.to)
                for g in gs.members:
                    if _nametarget == g.displayName:
                       cl.sendText(msg.to,"Otw..wkwk")
                       ki.sendText(g.mid,"Duarr  􀜁􀅔Har Har􏿿")  
                       kk.sendText(g.mid,"DorrDorr  􀜁􀅔Har Har􏿿")  
                       kc.sendText(g.mid,"Darrr..  􀜁􀅔Har Har􏿿")
                       ks.sendText(g.mid,"Derrr  􀜁􀅔Har Har􏿿")
                       ka.sendText(g.mid,"Dorr  􀜁􀅔Har Har􏿿")
                       kb.sendText(g.mid,"Duarrrrrr  􀜁􀅔Har Har􏿿")
                       ko.sendText(g.mid,"Boomm..!!  ????Har Har􏿿")
                       ke.sendText(g.mid,"Boomm..!!  ??􀅔Har Har􏿿")
                       ku.sendText(g.mid,"Boomm..!!  􀜁􀅔Har Har􏿿")
                       kv.sendText(g.mid,"Boomm..!!  􀜁􀅔Har Har􏿿")
                       kw.sendText(g.mid,"Duarr  􀜁􀅔Har Har􏿿")  
                       kx.sendText(g.mid,"Duarr  􀜁􀅔Har Har􏿿")  
                       ki.sendText(g.mid,"Awas ledakan  􀜁􀅔Har Har􏿿")
                       kk.sendText(g.mid,"Dorrrrrrrrrrrr  􀜁􀅔Har Har􏿿")
                       kc.sendText(g.mid,"Duarrrrr  􀜁􀅔Har Har􏿿")  
                       ks.sendText(g.mid,"Spam  􀜁􀅔Har Har􏿿")
                       ka.sendText(g.mid,"Awas ledakan  􀜁􀅔Har Har􏿿")
                       kb.sendText(g.mid,"Dorrrr  􀜁􀅔Har Har􏿿")
                       ko.sendText(g.mid,"Daarrrrr!!  􀜁􀅔Har Har??")
                       ke.sendText(g.mid,"Daarrrrr!!  􀜁􀅔Har Har??")
                       ku.sendText(g.mid,"Daarrrrr!!  􀜁􀅔Har Har??")
                       kv.sendText(g.mid,"Daarrrrr!!  􀜁􀅔Har Har??")
                       kw.sendText(g.mid,"Duarr  􀜁􀅔Har Har􏿿") 
                       kx.sendText(g.mid,"Duarr  􀜁􀅔Har Har􏿿")   
                       ki.sendText(g.mid,"Deerrrrr!!  􀜁􀅔Har Har􏿿")
                       kk.sendText(g.mid,"Doorrrrr!  􀜁􀅔Har Har􏿿")
                       kc.sendText(g.mid,"Doorrrrr!  􀜁􀅔Har Har􏿿")
                       ks.sendText(g.mid,"Doorrrrr!  􀜁􀅔Har Har􏿿")
                       ka.sendText(g.mid,"Doorrrrr!  􀜁􀅔Har Har􏿿")
                       kb.sendText(g.mid,"Doorrrrr!  􀜁􀅔Har Har􏿿")
                       ko.sendText(g.mid,"Doorrrrr!  􀜁􀅔Har Har􏿿")
                       ke.sendText(g.mid,"Doorrrrr!  􀜁􀅔Har Har??")
                       ku.sendText(g.mid,"Doorrrrr!  􀜁􀅔Har Har􏿿")
                       kv.sendText(g.mid,"Doorrrrr!  􀜁􀅔Har Har􏿿")
                       kw.sendText(g.mid,"Duarr  􀜁􀅔Har Har􏿿")  
                       kx.sendText(g.mid,"Duarr  􀜁􀅔Har Har􏿿")  
                       cl.sendText(msg.to, "Done  􀜁􀅔Har Har􏿿")
                       print "Done spam" 
#--------------------------------------------------------------#
            elif "Anu @" in msg.text:
              if msg.from_ in admin:
                _name = msg.text.replace("Anu @","")
                _nametarget = _name.rstrip(' ')
                gs = cl.getGroup(msg.to)
                for g in gs.members:
                    if _nametarget == g.displayName:
                       cl.sendText(msg.to,"Anu...")
                       ki.sendText(g.mid,"Duarr  􀜁􀅔Har Har􏿿")  
                       kk.sendText(g.mid,"DorrDorr  􀜁􀅔Har Har􏿿")  
                       kc.sendText(g.mid,"Darrr..  􀜁􀅔Har Har􏿿")
                       ks.sendText(g.mid,"Derrr  􀜁􀅔Har Har􏿿")
                       ka.sendText(g.mid,"Dorr  􀜁􀅔Har Har􏿿")
                       kb.sendText(g.mid,"Duarrrrrr  􀜁􀅔Har Har􏿿")
                       ko.sendText(g.mid,"Boomm..!!  􀜁􀅔Har Har??")
                       ke.sendText(g.mid,"Boomm..!!  􀜁􀅔Har Har􏿿")
                       ku.sendText(g.mid,"Boomm..!!  􀜁􀅔Har Har􏿿")
                       kv.sendText(g.mid,"Boomm..!!  􀜁􀅔Har Har􏿿")
                       ki.sendText(g.mid,"Awas ledakan  􀜁􀅔Har Har􏿿")
                       kk.sendText(g.mid,"Dorrrrrrrrrrrr  􀜁􀅔Har Har􏿿")
                       kc.sendText(g.mid,"Duarrrrr  􀜁􀅔Har Har􏿿")  
                       ks.sendText(g.mid,"Spam  􀜁􀅔Har Har􏿿")
                       ka.sendText(g.mid,"Awas ledakan  􀜁􀅔Har Har􏿿")
                       kb.sendText(g.mid,"Dorrrr  􀜁􀅔Har Har􏿿")
                       ko.sendText(g.mid,"Daarrrrr!!  􀜁􀅔Har Har??")
                       ke.sendText(g.mid,"Daarrrrr!!  􀜁􀅔Har Har??")
                       ku.sendText(g.mid,"Daarrrrr!!  􀜁􀅔Har Har??")
                       kv.sendText(g.mid,"Daarrrrr!!  􀜁􀅔Har Har??")
                       ki.sendText(g.mid,"Deerrrrr!!  􀜁􀅔Har Har􏿿")
                       kk.sendText(g.mid,"Doorrrrr!  􀜁􀅔Har Har􏿿")
                       kc.sendText(g.mid,"Doorrrrr!  􀜁􀅔Har Har􏿿")
                       ks.sendText(g.mid,"Doorrrrr!  􀜁􀅔Har Har􏿿")
                       ka.sendText(g.mid,"Doorrrrr!  􀜁􀅔Har Har􏿿")
                       kb.sendText(g.mid,"Doorrrrr!  􀜁􀅔Har Har􏿿")
                       ko.sendText(g.mid,"Doorrrrr!  􀜁􀅔Har Har􏿿")
                       ke.sendText(g.mid,"Doorrrrr!  􀜁􀅔Har Har􏿿")
                       ku.sendText(g.mid,"Doorrrrr!  􀜁􀅔Har Har􏿿")
                       kv.sendText(g.mid,"Doorrrrr!  􀜁􀅔Har Har􏿿")
                       cl.sendText(msg.to, "Cabut......  􀜁􀅔Har Har􏿿")
                       print "Done spam" 

#--------------------------------------------------------------#
#Cara pake (Spam on/off <100> hai)
            elif "Spam " in msg.text:
                if msg.from_ in admin:
                   txt = msg.text.split(" ")
                   jmlh = int(txt[2])
                   teks = msg.text.replace("Spam "+str(txt[1])+" "+str(jmlh)+ " ","")
                   tulisan = jmlh * (teks+"\n")
                   #cara pake [Spam on 100 <teks>]
                   #[Spam off 100 <teks>]
                   if txt[1] == "on":
                        if jmlh <= 10000:
                             for x in range(jmlh):
                                   cl.sendText(msg.to, teks)
                        else:
                               cl.sendText(msg.to, "Ga bisa bego Kelewatan batas...! ")
                   elif txt[1] == "off":
                         if jmlh <= 10000:
                               cl.sendText(msg.to, tulisan)
                         else:
                               cl.sendText(msg.to, "Ehm...kelewatan batas bro...!")
#------------------------------------------------------------
            elif "Spammid " in msg.text:
                korban = msg.text.replace("Spammid ","")
                korban2 = korban.split()
                midd = korban2[0]
                jumlah = int(korban2[1])
                spamnya = korban.replace(midd+" "+korban2[1]+ " ","")
                if jumlah <= 10000:
                    for var in range(0,jumlah):
                        cl.sendText(midd,spamnya)
                        cl.sendText(msg.to,"Done  􀜁􀅔Har Har􏿿  􀜁􀅔Har Har􏿿")
                else:
                    cl.sendText(msg.to, "Ehm...kelewatan batas bro...!")
                print "Spam Mid"
#--------------------------------------------------------
            elif msg.text in ["chat"]:
              if msg.from_ in admin:
                wait["CHAT"] = True
                cl.sendText(msg.to,"Send Contact Yang Akan Di Pc􀜁􀅔Har Har􏿿􀜁􀅔Har Har􏿿") 
#======================================================# 
            elif wait["CHAT"] == True:
           	_name = msg.contentMetadata["displayName"]
                target = msg.contentMetadata["mid"]
                groups = cl.getGroup(msg.to)
                pending = groups.invitee
                text = wait["message"]
                targets = []
                if targets == []:
                   pass
                else:
                    for target in targets:
                       try:
                           cl.findAndAddContactsByMid(target)
                           contact = cl.getContact(target)
                           cl.sendText(target,text)
                           cl.sendText(msg.to,"Pesan Telah Sampai Ke " + contact.displayName)
                           wait["CHAT"] = False
                       except Exception as error:
                   	   print error
          #      except Exception as error:
         #            print error
#--------------------------------------------------------
            elif msg.text in ["Bom"]:
              if msg.from_ in admin:
                wait["spam"] = True
                cl.sendText(msg.to,"Send Contact Yang Akan Di Bom􀜁􀅔Har Har􏿿􀜁􀅔Har Har􏿿")
#======================================================# 
            elif wait["spam"] == True:
                if msg.from_ in admin:
                    target = msg.contentMetadata["mid"]
                    text = "DUUAAARRRRR􀜁􀅔Har Har􏿿􀜁􀅔Har Har􏿿"
                    jumlah = int("4")
                    if jumlah <= 4:
                        for var in range(jumlah):
                             ki.sendText(target,text)
                             kk.sendText(target,text)
                             kc.sendText(target,text)
                             ks.sendText(target,text)
                             ka.sendText(target,text)
                             kb.sendText(target,text)
                             ko.sendText(target,text)
                             ke.sendText(target,text)
                             ku.sendText(target,text)
                             kv.sendText(target,text)
                             kw.sendText(target,text)
                             kx.sendText(target,text)
                             cl.sendText(msg.to, "Bom Telah Diledakan􀜁􀅔Har Har􏿿")
                    else:
                        cl.sendText(msg.to, "Gagal Meledakan Bom")
#==================================================================================#
            elif msg.text in ["Runtime"]:
                try:
            	    mulai = time.time()
                    cl.sendText(msg.to, " 👇Bot sudah berjalan selama👇")
                    waktu = time.time() - mulai
                    cl.sendText(msg.to, "% % %" % (waktu))
                except Exception as error:
                    print error
#--------------------------------------------------------
            elif msg.text in ["speed","Speed"]:
              if msg.from_ in admin:      	
                start = time.time()
                cl.sendText(msg.to, "👇My speed👇")
                elapsed_time = time.time() - start
                cl.sendText(msg.to, "%sseconds" % (elapsed_time))
#--------------------------------------------------------#
            elif msg.text in ["Ban"]:
              if msg.from_ in admin:
                wait["wblacklist"] = True
                cl.sendText(msg.to,"Send Contact")
            elif msg.text in ["Unban"]:
              if msg.from_ in admin:
                wait["dblacklist"] = True
                cl.sendText(msg.to,"Send Contact")
#--------------------------------------------------------------#  
            elif msg.text in ["Banlist"]:
              if msg.from_ in admin:
                if wait["blacklist"] == {}:
                    cl.sendText(msg.to,"Not Blacklist User")
                else:
                    mc = ""
                    for mi_d in wait["blacklist"]:
                        mc += "->" +cl.getContact(mi_d).displayName + "\n"
                    cl.sendText(msg.to,mc)
#--------------------------------------------------------------#
            elif msg.text in ["Mid ban"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    group = cl.getGroup(msg.to)
                    gMembMids = [contact.mid for contact in group.members]
                    matched_list = []
                    for tag in wait["blacklist"]:
                        matched_list+=filter(lambda str: str == tag, gMembMids)
                    cocoa = ""
                    for mm in matched_list:
                        cocoa += mm + "\n"
                    cl.sendText(msg.to,cocoa + "")
#--------------------------------------------------------------#
            elif msg.text in ["Kill ban"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    group = cl.getGroup(msg.to)
                    gMembMids = [contact.mid for contact in group.members]
                    matched_list = []
                    for tag in wait["blacklist"]:
                        matched_list+=filter(lambda str: str == tag, gMembMids)
                    if matched_list == []:
                        cl.sendText(msg.to,"Tdk ada akun ter blacklist")
                        return
                    for jj in matched_list:
                        cl.kickoutFromGroup(msg.to,[jj])
                        ki.kickoutFromGroup(msg.to,[jj])
                        kk.kickoutFromGroup(msg.to,[jj])
                        kc.kickoutFromGroup(msg.to,[jj])
                        ks.kickoutFromGroup(msg.to,[jj])
                        ka.kickoutFromGroup(msg.to,[jj])
                        kb.kickoutFromGroup(msg.to,[jj])
                        ko.kickoutFromGroup(msg.to,[jj])
                        ke.kickoutFromGroup(msg.to,[jj])
                        ku.kickoutFromGroup(msg.to,[jj])
                        kv.kickoutFromGroup(msg.to,[jj])
                        kw.kickoutFromGroup(msg.to,[jj])
                    cl.sendText(msg.to,"Wkwk")
                    ki.sendText(msg.to,"User blacklist")
                    kk.sendText(msg.to,"Udah diusir")
                    kc.sendText(msg.to,"dari grup")
#======================================================# 
            elif msg.text in ["B","b","mangat"]:
              if msg.from_ in admin:
                if msg.toType == 2:
                    group = cl.getGroup(msg.to)
                    gMembMids = [contact.mid for contact in group.invitee]
                    for _mid in gMembMids:
                        cl.cancelGroupInvitation(msg.to,[_mid])
                    cl.sendText(msg.to,"B")
#Restart_Program
	    elif msg.text in ["Restart"]:
              if msg.from_ in Creator:
		cl.sendText(msg.to, "System Akan Di Reboot")
		restart_program()
		print "@Restart"
#--------------------------------------------------------------#
        if op.type == 55:
	    try:
	      group_id = op.param1
	      user_id=op.param2
	      subprocess.Popen('echo "'+ user_id+'|'+str(op.createdTime)+'" >> dataSeen/%s.txt' % group_id, shell=True, stdout=subprocess.PIPE, )
	    except Exception as e:
	      print e
	
        if op.type == 55:
            try:
                if op.param1 in wait2['readPoint']:
                    Name = cl.getContact(op.param2).displayName
                    if Name in wait2['readMember'][op.param1]:
                        pass
                    else:
                        wait2['readMember'][op.param1] += "\n􀜁􀅔Har Har􏿿。" + Name
                        wait2['ROM'][op.param1][op.param2] = "􀜁􀅔Har Har􏿿。" + Name
                else:
                    cl.sendText
            except:
                  pass
#--------------------------------------------------------------#
        if op.type == 59:
            print op


    except Exception as error:
        print error
def autoSta(): 
        try:
           for posts in cl.activity(1)["result"]["posts"]:
             if posts["postInfo"]["liked"] is False:
                if wait["likeOn"] == True:
                   cl.like(posts["userInfo"]["writerMid"], posts["postInfo"]["postId"], 1001)
                   print posts
                   if wait["commentOn"] == True:
                      if posts["userInfo"]["writerMid"] in wait["commentBlack"]:
                         pass
                      else:
                          cl.comment(posts["userInfo"]["writerMid"],posts["postInfo"]["postId"],wait["comment"])
        except Exception as error:
         print error
#--------------------------------------------------------------#
def restart_program():
    python = sys.executable
    os.execl(python, python, * sys.argv)
#--------------------------------------------------------------#
def a2():
    now2 = datetime.now()
    nowT = datetime.strftime(now2,"%M")
    if nowT[14:] in ["10","20","30","40","50","00"]:
        return False
    else:
        return True
#--------------------------------------------------------------#
while True:
    try:
        Ops = cl.fetchOps(cl.Poll.rev, 5)
    except EOFError:
        raise Exception("It might be wrong revision\n" + str(cl.Poll.rev))

    for Op in Ops:
        if (Op.type != OpType.END_OF_OPERATION):
            cl.Poll.rev = max(cl.Poll.rev, Op.revision)
            bot(Op)

